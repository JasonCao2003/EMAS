package com.xupt.emas.controller;


import com.xupt.emas.pojo.Feedbacks;
import com.xupt.emas.pojo.Recommendations;
import com.xupt.emas.pojo.Result;
import com.xupt.emas.service.ArticleService;
import com.xupt.emas.utils.ThreadLocalUtil;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Controller
@Validated
@RequestMapping("/article")
public class ArticleController {

    @Resource
    private ArticleService articleService;

    @PostMapping("listRecommends")
    public Result<?> listRecommend() {
        try {
            Map<String, Object> map = ThreadLocalUtil.get();
            Integer userid = (Integer) map.get("userid");
            List<Recommendations> recommends = articleService.recommendArticles(userid);
            return Result.success(recommends);
        } catch (Exception e) {
            return Result.error("未能获取到推荐列表");
        }
    }

    @RequestMapping("submitFeedback")
    public Result<?> submitFeedback(Integer articleId, String feedback) {
        try {
            Map<String, Object> map = ThreadLocalUtil.get();
            Integer userId = (Integer) map.get("userid");
            Feedbacks feedbacks = new Feedbacks(0, userId, articleId, feedback);
            articleService.submitFeedback(feedbacks);
            return Result.success("提交成功");
        } catch (Exception e) {
            return Result.error("提交失败");
        }
    }
}

package com.xupt.emas.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface SocketServer {

    String EmotionAnalysis(String identifier, byte[] content, int port);

    String LoginVerification(String data, int port);

    String saveFile(String username, String type, MultipartFile file) throws IOException;
}

package com.xupt.emas.service.impl;

import com.xupt.emas.mapper.RecordFaceMapper;
import com.xupt.emas.mapper.RecordTextMapper;
import com.xupt.emas.mapper.RecordVoiceMapper;
import com.xupt.emas.pojo.RecordsFace;
import com.xupt.emas.pojo.RecordsText;
import com.xupt.emas.pojo.RecordsVoice;
import com.xupt.emas.service.RecordService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


@Service
public class RecordServiceImpl implements RecordService {
    @Resource
    private RecordFaceMapper recordFaceMapper;
    @Resource
    private RecordTextMapper recordTextMapper;
    @Resource
    private RecordVoiceMapper recordVoiceMapper;


    @Override
    public int addFaceRecord(RecordsFace recordsFace) {
        recordFaceMapper.insert(recordsFace);
        return recordsFace.getFaceId();
    }

    @Override
    public int addVoiceRecord(RecordsVoice recordsVoice) {
        recordVoiceMapper.insert(recordsVoice);
        return recordsVoice.getVoiceId();
    }

    @Override
    public int addTextRecord(RecordsText recordsText) {
        recordTextMapper.insert(recordsText);
        return recordsText.getTextId();
    }


}

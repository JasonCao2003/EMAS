package com.xupt.emas.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import java.util.Date;

@Data
public class Users {

    // 用户ID, 自动递增无需校验
    private int userId;

    // 用户名
    @Pattern(regexp = "^\\S{5,16}$", message = "用户名长度必须在5到16之间")
    private String username;

    // 昵称
    @Pattern(regexp = "^\\S{0,10}$", message = "昵称不能超过10个字符")
    private String nickname;

    // 密码
    @Pattern(regexp = "^\\S{5,16}$", message = "密码长度必须在5到16之间")
    private String password;

    // 电子邮件
    @Pattern(regexp = "^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$", message = "邮箱格式不正确")
    private String email;

    // 头像路径
    private String avatar;

    // 性别
    @Pattern(regexp = "^\\S{0,3}$", message = "性别长度不能超过3字符")
    private String sex;

    // 生日
    @Past(message = "生日必须是过去的日期")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthday;

    // 创建时间
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdAt;

    // 更新时间
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updatedAt;
}


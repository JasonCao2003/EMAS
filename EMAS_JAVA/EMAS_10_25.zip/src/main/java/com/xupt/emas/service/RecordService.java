package com.xupt.emas.service;

import com.xupt.emas.pojo.RecordsFace;
import com.xupt.emas.pojo.RecordsText;
import com.xupt.emas.pojo.RecordsVoice;


public interface RecordService {
    int addFaceRecord(RecordsFace recordsFace);

    int addVoiceRecord(RecordsVoice recordsVoice);

    int addTextRecord(RecordsText recordsText);

}

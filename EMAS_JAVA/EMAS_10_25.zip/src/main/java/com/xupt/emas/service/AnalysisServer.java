package com.xupt.emas.service;

import com.xupt.emas.pojo.AnalysisResults;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface AnalysisServer {

    void addAnalysis(AnalysisResults analysisResults);

    String textEmotionAnalysis(String text);

    String voiceEmotionAnalysis(MultipartFile file) throws IOException;

    String faceEmotionAnalysis(MultipartFile file) throws IOException;

    List<AnalysisResults> listAnalysis(int userId);
}

package com.xupt.emas.service;

import com.xupt.emas.pojo.Articles;
import com.xupt.emas.pojo.Feedbacks;
import com.xupt.emas.pojo.Recommendations;

import java.util.List;


public interface ArticleService {

    // 增加文章
    void addArticle(Articles articles);

    // 删除文章
    void deleteArticle(int articleId);

    // 更新文章
    void updateArticle(Articles articles);

    // 查询所有文章
    List<Articles> getAllArticles();

    // 根据ID查文章
    Articles getArticleById(int articleId);

    // 推荐文章给用户
    List<Recommendations> recommendArticles(int userId);

    // 用户对文章进行点踩
    void submitFeedback(Feedbacks feedbacks);
}

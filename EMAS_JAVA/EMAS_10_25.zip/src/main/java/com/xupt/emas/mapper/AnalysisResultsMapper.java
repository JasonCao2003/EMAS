package com.xupt.emas.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xupt.emas.pojo.AnalysisResults;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AnalysisResultsMapper extends BaseMapper<AnalysisResults> {

    @Select("SELECT * FROM Analysis_Results WHERE user_id = #{userId}")
    List<AnalysisResults> selectByUserId(int userId);
}

package com.xupt.emas.controller;

import com.xupt.emas.pojo.*;
import com.xupt.emas.service.AnalysisServer;
import com.xupt.emas.service.SocketServer;
import com.xupt.emas.service.RecordService;
import com.xupt.emas.utils.ThreadLocalUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Controller
public class RecordController {
    @Resource
    private RecordService recordService;
    @Resource
    private AnalysisServer analysisServer;
    @Resource
    private SocketServer socketServer;

    @PostMapping("testRecord")
    public Result<?> TextRecord(String text) {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        Date now = new Date();

        String emotion = analysisServer.textEmotionAnalysis(text);
        RecordsText recordsText = new RecordsText(0, userid, text, emotion, now);
        int recordId = recordService.addTextRecord(recordsText);

        AnalysisResults analysisResults = new AnalysisResults(0, userid, "text", recordId, emotion, 1, now);
        analysisServer.addAnalysis(analysisResults);
        return Result.success();
    }

    @PostMapping("faceRecord")
    public Result<?> FaceRecord(@RequestParam("image") MultipartFile file) {
        if (file.isEmpty()) {
            return Result.error("文件为空");
        }
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        String username = (String) map.get("username");
        try {
            String filePath = socketServer.saveFile(username, "image", file);
            String emotion = analysisServer.faceEmotionAnalysis(file);
            Date now = new Date();

            RecordsFace recordsFace = new RecordsFace(0, userid, filePath, emotion, now);
            int recordId = recordService.addFaceRecord(recordsFace);

            AnalysisResults analysisResults = new AnalysisResults(0, userid, "face", recordId, emotion, 1, now);
            analysisServer.addAnalysis(analysisResults);
            return Result.success();
        } catch (IOException e) {
            e.printStackTrace();
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("voiceRecord")
    public Result<?> VoiceRecord(@RequestParam("audio") MultipartFile file) {
        if (file.isEmpty()) {
            return Result.error("文件为空");
        }
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        String username = (String) map.get("username");
        try {
            String filePath = socketServer.saveFile(username, "audio", file);
            String emotion = analysisServer.voiceEmotionAnalysis(file);
            Date now = new Date();

            RecordsVoice record = new RecordsVoice(0, userid, filePath, emotion, now);
            int recordId = recordService.addVoiceRecord(record);

            AnalysisResults analysisResults = new AnalysisResults(0, userid, "voice", recordId, emotion, 1, now);
            analysisServer.addAnalysis(analysisResults);
            return Result.success();
        } catch (IOException e) {
            e.printStackTrace();
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("listAnalysis")
    public Result<?> listAnalysis() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        List<AnalysisResults> results = analysisServer.listAnalysis(userid);
        return Result.success(results);
    }


}

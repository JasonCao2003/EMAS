package com.xupt.emas.service.impl;

import com.xupt.emas.mapper.AnalysisResultsMapper;
import com.xupt.emas.pojo.AnalysisResults;
import com.xupt.emas.service.AnalysisServer;
import com.xupt.emas.service.SocketServer;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

@Service
public class AnalysisServerImpl implements AnalysisServer {

    @Resource
    private AnalysisResultsMapper analysisResultsMapper;
    @Resource
    private SocketServer socketServer;


    @Override
    public void addAnalysis(AnalysisResults analysisResults) {
        analysisResultsMapper.insert(analysisResults);
    }

    @Override
    public String textEmotionAnalysis(String text) {
        return socketServer.EmotionAnalysis("text", text.getBytes(), 12345);
    }

    @Override
    public String voiceEmotionAnalysis(MultipartFile file) throws IOException {
        return socketServer.EmotionAnalysis(Objects.requireNonNull(file.getOriginalFilename()), file.getBytes(), 12346);
    }


    @Override
    public String faceEmotionAnalysis(MultipartFile file) throws IOException {
        return socketServer.EmotionAnalysis(Objects.requireNonNull(file.getOriginalFilename()), file.getBytes(), 12347);
    }

    @Override
    public List<AnalysisResults> listAnalysis(int userId) {
        return analysisResultsMapper.selectByUserId(userId);
    }
}

package com.xupt.emas.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xupt.emas.pojo.Articles;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ArticleMapper extends BaseMapper<Articles> {
}

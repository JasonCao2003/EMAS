package com.xupt.emas.service.impl;

import com.xupt.emas.service.SocketServer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.net.Socket;
import java.util.UUID;

@Service
public class SocketServerImpl implements SocketServer {

    @Value("${file.upload-path}")
    private String basePath;

    @Override
    public String EmotionAnalysis(String identifier, byte[] content, int port) {
        String result = "";
        int attempts = 3; // 最大尝试次数
        while (attempts > 0) {
            try (Socket socket = new Socket("localhost", port)) {
                socket.setSoTimeout(5000); // 设置超时为5秒
                OutputStream os = socket.getOutputStream();
                // 发送文件名
                os.write(identifier.getBytes());
                os.write('\n');
                // 发送文件内容
                os.write(content);
                os.flush();
                // 获取分析结果
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                result = reader.readLine();
                return result;
            } catch (IOException e) {
                e.printStackTrace();
                attempts--;
                if (attempts == 0) {
                    return "分析失败";
                }
            }
        }
        return result; // 可能是空字符串
    }

    @Override
    public String LoginVerification(String data, int port) {
        String username = null;
        try (Socket socket = new Socket("localhost", port)) {
            OutputStream output = socket.getOutputStream();
            PrintWriter writer = new PrintWriter(output, true);

            // 发送人脸或者音频
            writer.println(data);

            // 从Python后端获取分析结果
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String response = reader.readLine();

            // 分析结果并获取有用数据
            if (response != null) {
                String[] parts = response.split(":");
                if (parts.length == 2 && "success".equals(parts[0])) {
                    username = parts[1];
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return username;
    }

    @Override
    public String saveFile(String username, String type, MultipartFile file) throws IOException {
        // 确定文件扩展名
        String extension = type.equals("image") ? ".jpg" : ".mp3";

        // 生成文件名
        String filename = UUID.randomUUID().toString() + extension;

        // 构建文件保存路径
        String directoryPath = basePath + File.separator + type + File.separator + username;
        File directory = new File(directoryPath);

        // 确保目录存在
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // 构建完整的文件路径
        File dest = new File(directory, filename);

        // 将文件保存到指定路径
        file.transferTo(dest);

        // 返回相对路径
        return directoryPath + File.separator + filename;
    }
}

package com.xupt.emas.controller;

import com.xupt.emas.pojo.Result;
import com.xupt.emas.pojo.Users;
import com.xupt.emas.service.UserService;
import com.xupt.emas.utils.MailTool;
import com.xupt.emas.utils.Md5Util;
import com.xupt.emas.utils.ThreadLocalUtil;
import org.hibernate.validator.constraints.URL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import java.util.Map;


@RestController
@Validated
@RequestMapping("/user")
public class UserController {

    @Resource
    private UserService userService;
    @Resource
    private MailTool mailTool;
    @Autowired
    private StringRedisTemplate redisTemplate;


    @RequestMapping("/register")
    public Result<?> register(@Valid @RequestBody Users u) {
        Users user = userService.getUserByUsername(u.getUsername());
        if (user == null) {
            userService.addUser(u.getUsername(), u.getPassword());
            return Result.success();
        }
        return Result.error("用户名已存在");
    }


    @PutMapping("/update")
    public Result<?> updateUser(@RequestBody @Validated Users user) {
        try {
            userService.updateUser(user);
            return Result.success("修改成功");
        } catch (Exception e) {
            return Result.error("修改失败");
        }
    }


    @PatchMapping("/updateAvatar")
    public Result<?> updateAvatar(@RequestParam @URL(message = "需要合法的URL") String avatarUrl) {
        try {
            Map<String, Object> map = ThreadLocalUtil.get();
            Integer userid = (Integer) map.get("userid");
            userService.updateAvatar(avatarUrl, userid);
            return Result.success();
        } catch (Exception e) {
            return Result.error("头像修改失败");
        }
    }


    @PostMapping("emailValidation")
    public Result<?> emailValidation() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userId = (Integer) map.get("userid");
        Users user = userService.getUserById(userId);
        if (user.getEmail() != null) {
            return mailTool.SendValidation(user.getEmail());
        }
        return Result.error("此账号未绑定邮箱");
    }


    @PostMapping("/updatePwd")
    public Result<?> updatePwd(String oldPwd, String newPwd, String rePwd, String code) {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        Users user = userService.getUserById(userid);
        if (newPwd.equals(rePwd)) {
            if (Md5Util.getMD5String(oldPwd).equals(user.getPassword())) {
                return Result.error("与原密码相同");
            } else {
                ValueOperations<String, String> operator = redisTemplate.opsForValue();
                if (code.equals(operator.get(user.getEmail()))) {
                    userService.updatePwd(newPwd, userid);
                    return Result.success("修改成功，请重新登录");
                } else {
                    return Result.error("验证码错误");
                }
            }
        }
        return Result.error("两次密码不一致");
    }


    @PostMapping("/deleteUser")
    public Result<?> deleteUser(String code) {
        try {
            Map<String, Object> map = ThreadLocalUtil.get();
            Integer userid = (Integer) map.get("userid");
            Users user = userService.getUserById(userid);
            ValueOperations<String, String> operator = redisTemplate.opsForValue();
            if (code.equals(operator.get(user.getEmail()))) {
                userService.deleteUser(userid);
                return Result.success("已成功注销");
            } else {
                return Result.error("验证码错误");
            }
        }catch (Exception e) {
            return Result.error("注销失败");
        }
    }
}

package com.xupt.emas.controller;


import com.xupt.emas.pojo.Result;
import com.xupt.emas.pojo.Users;
import com.xupt.emas.service.SocketServer;
import com.xupt.emas.service.UserService;
import com.xupt.emas.utils.JwtUtil;
import com.xupt.emas.utils.MailTool;
import com.xupt.emas.utils.Md5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;
import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/login")
public class LoginController {

    @Resource
    private UserService userService;
    @Resource
    private MailTool mailTool;
    @Resource
    private SocketServer socketServer;
    @Autowired
    private StringRedisTemplate redisTemplate;


    @PostMapping("/pwdLogin")
    public Result<?> login(@Valid @RequestBody Users u) {
        Users user = userService.getUserByUsername(u.getUsername());
        if (user != null) {
            if (Md5Util.checkPassword(u.getPassword(), user.getPassword())) {
                return getToken(u.getUsername());
            } else {
                return Result.error("密码错误");
            }
        }
        return Result.error("用户不存在");
    }

    @PostMapping("/faceLogin")
    public Result<?> faceLogin(@RequestBody Map<String, String> payload) {
        String imageData = payload.get("image");
        String username = socketServer.LoginVerification(imageData, 34563);
        return getToken(username);
    }

    @PostMapping("/voiceLogin")
    public Result<?> voiceLogin(@RequestBody Map<String, String> payload) {
        String audioData = payload.get("audio");
        String username = socketServer.LoginVerification(audioData, 12343);
        return getToken(username);
    }

    @PostMapping("emailLogin")
    public Result<?> emailLogin(@Email(message = "邮箱格式错误") String email, String code) {
        Users user = userService.getUserByEmail(email);
        if (user != null) {
            ValueOperations<String, String> operator = redisTemplate.opsForValue();
            if (code.equals(operator.get(email))) {
                return getToken(user.getUsername());
            }
            return Result.error("验证码错误");
        }
        return Result.error("邮箱未验证或绑定");
    }


    @PostMapping("sendValidation")
    public Result<?> SendValidation(@Email String email) {
        Users user = userService.getUserByEmail(email);
        if (user != null) {
            return mailTool.SendValidation(email);
        }
        return Result.error("此邮箱未绑定或者未注册");
    }


    private Result<?> getToken(String username) {
        Users user = userService.getUserByUsername(username);
        if (user != null) {
            Map<String, Object> claims = new HashMap<>();
            claims.put("userid", user.getUserId());
            claims.put("username", username);
            String token = JwtUtil.genToken(claims);
            return Result.success(token);
        } else {
            return Result.error("登录失败");
        }
    }
}

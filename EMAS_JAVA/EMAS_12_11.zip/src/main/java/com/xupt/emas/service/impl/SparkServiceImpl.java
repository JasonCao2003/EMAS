package com.xupt.emas.service.impl;

import com.xupt.emas.pojo.Result;
import com.xupt.emas.service.SparkService;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class SparkServiceImpl implements SparkService {

    private static final RestTemplate restTemplate = new RestTemplate();
    private static final String BASE_PATH = "http://ab4dea.natappfree.cc";
//    private static final String BASE_PATH = "http://127.0.0.1:5000";


    @Override
    public String Text2Emo(String text) throws Exception {
        String url = BASE_PATH + "/classify_text2emo";
        Result<?> result = SendText(url, text);
        if (result.getCode() != 1) {
            return GetMainInfo("text2emo", result.getData().toString());
        }
        return null;
    }

    @Override
    public String Face2Emo(MultipartFile file) throws Exception {
        String url = BASE_PATH + "/predict_facemoe";
        Result<?> result = SendFile("image", file, url, null);
        if (result.getCode() != 1) {
            return GetMainInfo("face2emo", result.getData().toString());
        }
        return null;
    }

    @Override
    public String Voice2Emo(MultipartFile file) throws Exception {
        String url = BASE_PATH + "/classify_audio2emo";
        Result<?> result = SendFile("audio", file, url, null);
        if (result.getCode() != 1) {
            return GetMainInfo("voice2emo", result.getData().toString());
        }
        return null;
    }

    @Override
    public String Face2User(MultipartFile file) throws Exception {
        String url = BASE_PATH + "/detect_faceid";
        Result<?> result = SendFile("image", file, url, null);
        if (result.getCode() != 1) {
            return GetMainInfo("face2user", result.getData().toString());
        }
        return null;
    }

    @Override
    public String Voice2User(MultipartFile file) throws Exception {
        String url = BASE_PATH + "/verify_audioid";
        Result<?> result = SendFile("speaker1", file, url, null);
        if (result.getCode() != 1) {
            return GetMainInfo("voice2user", result.getData().toString());
        }
        return null;
    }

    @Override
    public Result<?> UploadFaceInfo(MultipartFile file, String username) throws Exception {
        String url = BASE_PATH + "/upload_face";
        Result<?> result = SendFile("image", file, url, username + ".jpg");
        if (result.getCode() != 1) {
            return Result.success();
        }
        return Result.error("上传失败");
    }

    @Override
    public Result<?> UploadVoiceInfo(MultipartFile file, String username) throws Exception {
        String url = BASE_PATH + "/upload_voice";
        Result<?> result = SendFile("audio", file, url, username + ".wav");
        if (result.getCode() != 1) {
            return Result.success();
        }
        return Result.error("上传失败");
    }

    // 从响应中获取emotion或者username
    private String GetMainInfo(String type, String responseBody) throws JSONException {
        switch (type) {
            case "text2emo" -> {
                JSONObject jsonResponse = new JSONObject(responseBody);
                String label = jsonResponse.getJSONArray("results")
                        .getJSONObject(0)
                        .getString("label");
                return URLDecoder.decode(label, StandardCharsets.UTF_8);
            }
            case "face2emo" -> {
                JSONObject jsonResponse = new JSONObject(responseBody);
                return jsonResponse.getString("predicted_emotion");
            }
            case "voice2emo" -> {
                JSONObject jsonResponse = new JSONObject(responseBody);
                JSONObject emotion = jsonResponse.getJSONObject("emotion");
                JSONArray labelArray = emotion.getJSONArray("label");
                return labelArray.getString(0);
            }
            case "face2user" -> {
                JSONObject jsonResponse = new JSONObject(responseBody);
                JSONArray results = jsonResponse.getJSONArray("results");
                String result = results.getString(1);
                return result.split(" ")[0];
            }
            case "voice2user" -> {
                JSONArray jsonArray = new JSONArray(responseBody);
                JSONObject jsonObject = jsonArray.getJSONObject(0);
                String filename = jsonObject.getString("filename");
                return filename.substring(0, filename.lastIndexOf('.'));
            }
        }
        return null;
    }

    public Result<?> SendText(String url, String text) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        String requestBody = "{\"text\": \"" + text + "\"}";
        HttpEntity<String> requestEntity = new HttpEntity<>(requestBody, headers);
        return SendRequest(url, requestEntity);
    }

    public Result<?> SendFile(String fileType, MultipartFile multipartFile, String url, String fileName) throws IOException {
        // 文件类型转换
        if (fileName == null) {
            fileName = multipartFile.getOriginalFilename();
        }
        File file = new File(System.getProperty("java.io.tmpdir") + File.separator + fileName);
        multipartFile.transferTo(file);
        // 构建HttpEntity
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        String mimeType = GetMimeType(multipartFile);
        MultipartBodyBuilder builder = new MultipartBodyBuilder();
        builder.part(fileType, new FileSystemResource(file)).header("Content-Type", mimeType);
        MultiValueMap<String, HttpEntity<?>> multipartRequest = builder.build();
        HttpEntity<MultiValueMap<String, HttpEntity<?>>> requestEntity = new HttpEntity<>(multipartRequest, headers);
        // 发送请求
        return SendRequest(url, requestEntity);
    }

    // 发送请求和响应处理
    private Result<?> SendRequest(String url, HttpEntity<?> requestEntity) {
        ResponseEntity<String> response = restTemplate.exchange(
                url,
                HttpMethod.POST,
                requestEntity,
                String.class
        );
        if (response.getStatusCode().is2xxSuccessful()) {
            return Result.success(DecodeUnicode(response.getBody()));
        } else {
            return Result.error("请求失败，错误状态码：" + response.getStatusCodeValue());
        }
    }

    // 对响应内容重新编码
    private String DecodeUnicode(String str) {
        Pattern pattern = Pattern.compile("\\\\u([0-9a-fA-F]{4})");
        Matcher matcher = pattern.matcher(str);
        StringBuilder sb = new StringBuilder();
        while (matcher.find()) {
            String unicode = matcher.group(1);
            char ch = (char) Integer.parseInt(unicode, 16);
            matcher.appendReplacement(sb, String.valueOf(ch));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    // 获取上传文件的媒体类型
    private String GetMimeType(MultipartFile file) {
        String fileName = Objects.requireNonNull(file.getOriginalFilename()).toLowerCase();
        if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) {
            return "image/jpeg";
        } else if (fileName.endsWith(".png")) {
            return "image/png";
        } else if (fileName.endsWith(".wav")) {
            return "audio/wav";
        } else if (fileName.endsWith(".mp3")) {
            return "audio/mp3";
        } else {
            return MimeTypeUtils.APPLICATION_OCTET_STREAM_VALUE;
        }
    }
}

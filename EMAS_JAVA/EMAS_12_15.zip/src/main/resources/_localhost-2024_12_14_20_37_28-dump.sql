-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: emas
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `analysis_results`
--

DROP TABLE IF EXISTS `analysis_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `analysis_results` (
  `analysis_id` int NOT NULL AUTO_INCREMENT COMMENT '分析结果ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `source_type` enum('text','face','voice') NOT NULL COMMENT '来源类型',
  `source_id` int DEFAULT NULL COMMENT '来源记录ID',
  `emotion` varchar(10) DEFAULT NULL COMMENT '情绪',
  `confidence` float DEFAULT NULL COMMENT '置信度',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`analysis_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `analysis_results_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analysis_results`
--

LOCK TABLES `analysis_results` WRITE;
/*!40000 ALTER TABLE `analysis_results` DISABLE KEYS */;
INSERT INTO `analysis_results` VALUES (1,1,'text',1,'快乐',0.95,'2024-12-12 15:59:57'),(2,2,'face',2,'悲伤',0.85,'2024-12-12 15:59:57'),(3,3,'voice',3,'愤怒',0.9,'2024-12-12 15:59:57'),(4,4,'text',4,'惊讶',0.88,'2024-12-12 15:59:57');
/*!40000 ALTER TABLE `analysis_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `article_id` int NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `title` varchar(255) NOT NULL COMMENT '文章标题',
  `content` text NOT NULL COMMENT '文章内容',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `summary` varchar(1000) DEFAULT NULL COMMENT '文章概述',
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,'美丽的九寨沟','九寨沟位于四川省阿坝藏族羌族自治州，是中国最著名的自然保护区之一。这里有着清澈见底的湖泊、壮观的瀑布群和五彩斑斓的森林，吸引了无数游客前来观赏。九寨沟的水清澈透明，色彩斑斓，每个季节都有不同的景色。春天，万物复苏，花儿竞相开放；夏天，绿树成荫，清凉宜人；秋天，层林尽染，五彩斑斓；冬天，银装素裹，宛如仙境。','2024-11-13 13:50:19','2024-11-13 13:50:19','九寨沟以其清澈的湖泊、壮观的瀑布群和多彩的森林而闻名。'),(2,'北京烤鸭的魅力','北京烤鸭是中国传统名菜之一，以其皮脆肉嫩、色泽鲜亮而闻名。烤鸭通常搭配葱丝、黄瓜条和甜面酱一起食用，味道十分美味。制作烤鸭的过程非常讲究，首先选用优质肥鸭，经过腌制、挂炉烤制等多道工序，最终呈现出外皮酥脆、内肉鲜嫩的特点。在北京，有许多知名的烤鸭店，如全聚德、便宜坊等，每一家都有自己独特的风味。','2024-11-13 13:50:19','2024-11-13 13:50:19','北京烤鸭是中国传统名菜，以其皮脆肉嫩、色泽鲜亮而著称。'),(3,'初恋的感觉','初恋总是让人难以忘怀，那些美好的回忆常常在心中回荡。第一次牵手时的紧张和兴奋，第一次约会时的心跳加速，第一次拥抱时的温暖和幸福……每一个瞬间都充满了甜蜜与青涩。初恋的美好不仅在于对方的存在，更在于那段纯真的时光，让人怀念不已。即使最终没有走到一起，那份美好的回忆也会成为一生中最宝贵的财富。','2024-11-13 13:50:19','2024-11-13 13:50:19','初恋总是让人难以忘怀，那些美好的回忆常常在心中回荡。'),(4,'上海外滩夜景','上海外滩的夜景美轮美奂，灯光璀璨，令人流连忘返。黄浦江两岸的高楼大厦倒映在水中，形成一幅美丽的画卷。夜晚的外滩，人流如织，霓虹灯闪烁，各种建筑风格的楼宇交相辉映，展现出上海这座城市的繁华与魅力。站在外滩，可以欣赏到对岸陆家嘴金融区的现代化建筑群，如东方明珠塔、环球金融中心等，也可以感受到老上海的历史韵味。','2024-11-13 13:50:19','2024-11-13 13:50:19','上海外滩的夜景美轮美奂，灯光璀璨，令人流连忘返。'),(5,'四川火锅的独特风味','四川火锅是中国特色美食之一，以其麻辣鲜香、热气腾腾而受到食客的喜爱。锅底通常由多种香料和辣椒熬制而成，搭配各种食材，如毛肚、黄喉、豆皮、豆腐等，味道丰富多样。四川火锅不仅是一种美食，更是一种文化体验。围坐在火锅旁，一边品尝美食，一边聊天谈笑，气氛非常热烈。无论是寒冷的冬夜还是炎热的夏日，四川火锅都能带来独特的享受。','2024-11-13 13:50:19','2024-11-13 13:50:19','四川火锅以其麻辣鲜香、热气腾腾而受到食客的喜爱。'),(6,'秋日的静谧','秋天是一个收获的季节，也是最宁静美好的时光。金黄色的树叶随风飘动，空气中弥漫着淡淡的果香，一切都显得那么和谐美好。田野里，稻谷成熟了，农民们忙碌着收割；果园里，苹果和梨挂满枝头，等待采摘。秋天的天空格外高远，阳光明媚而不刺眼，微风吹过，带来丝丝凉意。走在林间小道上，踩着落叶，感受大自然的宁静与美丽，让人心情舒畅。','2024-11-13 13:50:19','2024-11-13 13:50:19','秋天是一个收获的季节，也是最宁静美好的时光。'),(7,'意大利面的制作方法','意大利面是一道简单又美味的西餐主食，适合家庭制作。主要材料有意大利面条、番茄酱、橄榄油和各种蔬菜肉类，烹饪方法多样，口感丰富。首先，将意大利面条煮至八分熟，捞出备用；然后，在锅中加入橄榄油，炒香蒜末和洋葱，再加入切好的肉末和蔬菜，翻炒均匀；接着，倒入适量的番茄酱，加入盐、胡椒粉等调味料，煮沸后放入意大利面条，翻炒均匀即可。最后，撒上一些新鲜的罗勒叶和帕尔马干酪，美味的意大利面就完成了。','2024-11-13 13:50:19','2024-11-13 13:50:19','意大利面是一道简单又美味的西餐主食，适合家庭制作。'),(8,'爱情的真谛','爱情不仅仅是浪漫和激情，更是一种责任和付出。真正的爱情需要双方共同经营，相互理解和支持，才能长久地走下去。在恋爱关系中，不仅仅是享受彼此的陪伴和快乐，更需要在困难和挑战面前携手共进。无论是生活中的琐事还是重要的决策，都需要双方共同努力。爱情中的信任、尊重和包容是维持关系的重要基石。只有真正懂得付出和珍惜，才能让爱情之树常青。','2024-11-13 13:50:19','2024-11-13 13:50:19','爱情不仅仅是浪漫和激情，更是一种责任和付出。'),(9,'云南大理的风情','大理是一个充满诗意的地方，白墙黑瓦的古建筑与碧水蓝天交相辉映。洱海的湖光山色、古城的街道巷弄，都让人感受到浓厚的文化氛围。大理古城保存了许多明清时期的建筑，走在石板路上，仿佛穿越了时空。洱海的湖水清澈见底，周围环绕着苍山，景色十分迷人。每年的三月街节，大理都会举办盛大的民族活动，吸引来自各地的游客。','2024-11-13 13:50:19','2024-11-13 13:50:19','大理是一个充满诗意的地方，白墙黑瓦的古建筑与碧水蓝天交相辉映。'),(10,'法式甜点的魅力','法式甜点以其精致的外观和细腻的口感征服了全世界的美食爱好者。马卡龙、拿破仑蛋糕、法式奶油泡芙等都是经典之作，每一口都让人陶醉。马卡龙是一种小巧精致的夹心饼干，外壳酥脆，内馅丰富，常见的口味有杏仁、巧克力、草莓等。拿破仑蛋糕由多层酥皮和奶油组成，口感层次分明，甜而不腻。法式奶油泡芙则是一种空心的小圆球，里面填满了香浓的奶油，外表撒上一层糖粉，非常诱人。无论是作为下午茶的点心还是庆祝节日的甜品，法式甜点都能带来极致的味觉享受。','2024-11-13 13:50:19','2024-11-13 13:50:19','法式甜点以其精致的外观和细腻的口感征服了全世界的美食爱好者。'),(11,'桂林山水甲天下','桂林山水以其秀美的山峦和清澈的河流而闻名于世。漓江两岸的山峰形态各异，翠竹倒映在清澈的江水中，构成了一幅幅美丽的画卷。乘船游览漓江，可以欣赏到象鼻山、九马画山等著名景点，感受大自然的鬼斧神工。','2024-11-13 13:51:48','2024-11-13 13:51:48','桂林山水以其秀美的山峦和清澈的河流而闻名于世。'),(12,'日本寿司的文化','寿司是日本的传统美食，以其新鲜的食材和精致的工艺而著称。寿司的主要材料包括生鱼片、海鲜、米饭等，搭配酱油和芥末食用。制作寿司的过程非常讲究，从选材到切片再到摆盘，每一步都要求精细。在日本，许多寿司店都有着悠久的历史，传承了几代人的技艺。','2024-11-13 13:51:48','2024-11-13 13:51:48','寿司是日本的传统美食，以其新鲜的食材和精致的工艺而著称。'),(13,'爱情的酸甜苦辣','爱情中有甜蜜也有苦涩，每一种滋味都值得细细品味。甜蜜时，两个人手牵手漫步在街头，分享彼此的喜怒哀乐；苦涩时，面对误解和争吵，需要更多的理解和宽容。爱情如同一杯调好的鸡尾酒，酸甜苦辣交织在一起，让人回味无穷。','2024-11-13 13:51:48','2024-11-13 13:51:48','爱情中有甜蜜也有苦涩，每一种滋味都值得细细品味。'),(14,'巴黎塞纳河畔','巴黎塞纳河畔是浪漫之都的一道亮丽风景线。河边的散步道两旁种满了梧桐树，四季变换，景色各异。沿岸有许多著名的景点，如埃菲尔铁塔、卢浮宫、奥赛博物馆等。夜晚，河上的灯光璀璨，游船缓缓行驶，营造出一种浪漫的氛围。','2024-11-13 13:51:48','2024-11-13 13:51:48','巴黎塞纳河畔是浪漫之都的一道亮丽风景线。'),(15,'广东早茶的魅力','广东早茶是广东人生活中不可或缺的一部分，以其品种繁多和味道鲜美而著称。常见的早茶点心有虾饺、烧卖、凤爪、肠粉等，每一种都有独特的风味。早茶不仅仅是食物的享受，更是一种社交活动，亲朋好友围坐一桌，边吃边聊，其乐融融。','2024-11-13 13:51:48','2024-11-13 13:51:48','广东早茶是广东人生活中不可或缺的一部分，以其品种繁多和味道鲜美而著称。'),(16,'旅行的意义','旅行不仅仅是身体的移动，更是心灵的成长和释放。每一次旅行都是一次新的探索，可以见识不同的文化和风景，结识新朋友，拓宽视野。旅行中遇到的挑战和困难，也能锻炼人的意志和能力。旅行归来，往往会发现自己的心境变得更加开阔和成熟。','2024-11-13 13:51:48','2024-11-13 13:51:48','旅行不仅仅是身体的移动，更是心灵的成长和释放。'),(17,'苏州园林的雅致','苏州园林是中国古典园林艺术的典范，以其精巧的设计和优美的景致而闻名。拙政园、留园、狮子林等都是著名的园林，园内亭台楼阁错落有致，山水布局巧妙，植物配置得当。漫步在园林中，可以感受到中国古代文人的雅致情趣和高超的艺术造诣。','2024-11-13 13:51:48','2024-11-13 13:51:48','苏州园林是中国古典园林艺术的典范，以其精巧的设计和优美的景致而闻名。'),(18,'法国葡萄酒的品鉴','法国葡萄酒以其悠久的历史和卓越的品质享誉世界。波尔多、勃艮第、香槟等产区各有特色，生产的葡萄酒种类繁多。品鉴葡萄酒不仅是一种味觉享受，更是一种文化和艺术的体验。通过观察颜色、闻香气、尝味道，可以全面了解一款葡萄酒的特点和品质。','2024-11-13 13:51:48','2024-11-13 13:51:48','法国葡萄酒以其悠久的历史和卓越的品质享誉世界。'),(19,'友情的力量','友情是人生旅途中最珍贵的财富之一，它可以给予我们支持和鼓励。真正的朋友会在我们需要帮助时伸出援手，在我们失落时给予安慰。友情的力量是无穷的，它可以让我们在困难面前更加坚强，也可以让我们在成功时更加谦逊。','2024-11-13 13:51:48','2024-11-13 13:51:48','友情是人生旅途中最珍贵的财富之一，它可以给予我们支持和鼓励。'),(20,'澳大利亚大堡礁的奇观','澳大利亚大堡礁是世界上最大的珊瑚礁系统，被誉为地球上最壮观的自然奇观之一。这里生活着丰富的海洋生物，如热带鱼、海龟、鲨鱼等。潜水或乘坐玻璃底船可以近距离观赏到五彩斑斓的珊瑚和各种奇特的海底景观。','2024-11-13 13:51:48','2024-11-13 13:51:48','澳大利亚大堡礁是世界上最大的珊瑚礁系统，被誉为地球上最壮观的自然奇观之一。'),(21,'西班牙弗拉门戈舞的热情','弗拉门戈舞是西班牙安达卢西亚地区的传统舞蹈，以其热情奔放和强烈的情感表达而著称。舞者通过脚步的踏击、手势的变化和身体的扭动，传达出内心的喜悦、悲伤和愤怒。弗拉门戈舞不仅是舞蹈，更是一种文化和生活方式，展现了西班牙人民的热情和活力。','2024-11-13 13:51:48','2024-11-13 13:51:48','弗拉门戈舞是西班牙安达卢西亚地区的传统舞蹈，以其热情奔放和强烈的情感表达而著称。'),(22,'云南过桥米线的故事','过桥米线是云南的传统美食，以其独特的烹饪方式和鲜美的味道而闻名。传说这道菜源于清朝时期，一位书生的妻子为了给丈夫送饭，发明了这种保持汤温的方法。过桥米线的汤底用鸡肉和猪骨长时间熬制而成，搭配米线、生肉片、蔬菜等多种配料，味道鲜美，营养丰富。','2024-11-13 13:51:48','2024-11-13 13:51:48','过桥米线是云南的传统美食，以其独特的烹饪方式和鲜美的味道而闻名。'),(23,'英国伦敦塔桥的历史','伦敦塔桥是伦敦的标志性建筑之一，见证了这座城市的历史变迁。塔桥建于19世纪末，是一座吊桥和开启桥的结合体，可以升起让大型船只通过。塔桥两侧的塔楼内设有展览馆，游客可以参观了解桥梁的历史和技术。站在塔桥上，可以俯瞰泰晤士河两岸的美景。','2024-11-13 13:51:48','2024-11-13 13:51:48','伦敦塔桥是伦敦的标志性建筑之一，见证了这座城市的历史变迁。'),(24,'韩国泡菜的制作方法','泡菜是韩国的传统发酵食品，以其酸辣可口的味道和丰富的营养价值而著称。制作泡菜的主要材料有白菜、萝卜、辣椒粉、大蒜、姜等，经过腌制和发酵过程，形成独特的风味。泡菜不仅可以单独食用，还可以作为烹饪的原料，增加菜肴的口感和风味。','2024-11-13 13:51:48','2024-11-13 13:51:48','泡菜是韩国的传统发酵食品，以其酸辣可口的味道和丰富的营养价值而著称。'),(25,'埃及金字塔的神秘','埃及金字塔是古代文明的奇迹，至今仍有许多未解之谜。吉萨金字塔群是最著名的金字塔群，包括胡夫金字塔、哈夫拉金字塔和门卡乌拉金字塔。这些金字塔内部结构复杂，外部宏伟壮观，展示了古埃及人民的智慧和建筑技术。','2024-11-13 13:51:48','2024-11-13 13:51:48','埃及金字塔是古代文明的奇迹，至今仍有许多未解之谜。'),(26,'泰国曼谷的夜市','曼谷的夜市是体验当地生活和文化的绝佳场所，各种小吃和手工艺品琳琅满目。阿索克夜市、乍都乍周末市场等都是非常受欢迎的夜市。游客可以在这里品尝到地道的泰国美食，如芒果糯米饭、泰式炒河粉、椰奶西米露等，还可以购买到各种手工艺品和纪念品。','2024-11-13 13:51:48','2024-11-13 13:51:48','曼谷的夜市是体验当地生活和文化的绝佳场所，各种小吃和手工艺品琳琅满目。'),(27,'巴西狂欢节的狂欢','巴西狂欢节是世界上最大规模的狂欢节之一，以其热烈的气氛和丰富多彩的活动而闻名。每年二月，巴西各地都会举行盛大的游行和派对，人们穿上五彩缤纷的服装，跳起桑巴舞，尽情狂欢。狂欢节不仅是巴西人民庆祝生活的节日，也吸引了来自世界各地的游客。','2024-11-13 13:51:48','2024-11-13 13:51:48','巴西狂欢节是世界上最大规模的狂欢节之一，以其热烈的气氛和丰富多彩的活动而闻名。'),(28,'新西兰皇后镇的冒险','皇后镇是新西兰著名的旅游胜地，被誉为“冒险之都”。这里有许多刺激的户外活动，如蹦极、滑翔伞、喷射快艇等。皇后镇周围的风景也非常美丽，湖光山色令人陶醉。无论你是寻求刺激的冒险者还是喜欢安静的观光客，都能在这里找到属于自己的乐趣。','2024-11-13 13:51:48','2024-11-13 13:51:48','皇后镇是新西兰著名的旅游胜地，被誉为“冒险之都”。'),(29,'印度泰姬陵的爱情故事','泰姬陵是印度最著名的建筑之一，被誉为“爱情的象征”。这座白色大理石陵墓是由莫卧儿帝国皇帝沙贾汗为纪念他已故的爱妃而建造的。泰姬陵的建筑精美绝伦，融合了伊斯兰、波斯和印度建筑风格，被誉为世界上最美的建筑之一。每年吸引着成千上万的游客前来参观。','2024-11-13 13:51:48','2024-11-13 13:51:48','泰姬陵是印度最著名的建筑之一，被誉为“爱情的象征”。'),(30,'日本京都的古韵','京都是日本传统文化的代表城市，保留了许多古老的寺庙和神社。金阁寺、清水寺、伏见稻荷大社等都是著名的旅游景点。京都的街道依然保持着传统的风貌，穿着和服漫步在古巷中，可以感受到浓郁的文化氛围。每年的樱花季和红叶季，京都更是美不胜收。','2024-11-13 13:51:48','2024-11-13 13:51:48','京都是日本传统文化的代表城市，保留了许多古老的寺庙和神社。'),(31,'美丽的九寨沟','九寨沟位于四川省阿坝藏族羌族自治州，是中国最著名的自然保护区之一。这里有着清澈见底的湖泊、壮观的瀑布群和五彩斑斓的森林，吸引了无数游客前来观赏。','2024-12-12 15:59:57','2024-12-12 15:59:57','九寨沟以其清澈的湖泊、壮观的瀑布群和多彩的森林而闻名。'),(32,'北京烤鸭的魅力','北京烤鸭是中国传统名菜之一，以其皮脆肉嫩、色泽鲜亮而闻名。烤鸭通常搭配葱丝、黄瓜条和甜面酱一起食用，味道十分美味。','2024-12-12 15:59:57','2024-12-12 15:59:57','北京烤鸭是中国传统名菜，以其皮脆肉嫩、色泽鲜亮而著称。'),(33,'初恋的感觉','初恋总是让人难以忘怀，那些美好的回忆常常在心中回荡。第一次牵手、第一次约会、第一次拥抱……每一个瞬间都充满了甜蜜与青涩。','2024-12-12 15:59:57','2024-12-12 15:59:57','初恋总是让人难以忘怀，那些美好的回忆常常在心中回荡。'),(34,'上海外滩夜景','上海外滩的夜景美轮美奂，灯光璀璨，令人流连忘返。黄浦江两岸的高楼大厦倒映在水中，形成一幅美丽的画卷。','2024-12-12 15:59:57','2024-12-12 15:59:57','上海外滩的夜景美轮美奂，灯光璀璨，令人流连忘返。');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedbacks`
--

DROP TABLE IF EXISTS `feedbacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedbacks` (
  `feedback_id` int NOT NULL AUTO_INCREMENT COMMENT '反馈ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `article_id` int DEFAULT NULL COMMENT '文章ID',
  `feedback` enum('like','dislike') DEFAULT NULL COMMENT '反馈类型',
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  KEY `article_id` (`article_id`),
  CONSTRAINT `feedbacks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `feedbacks_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `articles` (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedbacks`
--

LOCK TABLES `feedbacks` WRITE;
/*!40000 ALTER TABLE `feedbacks` DISABLE KEYS */;
INSERT INTO `feedbacks` VALUES (1,1,1,'like'),(2,2,2,'dislike'),(3,3,3,'like'),(4,4,4,'dislike');
/*!40000 ALTER TABLE `feedbacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendations`
--

DROP TABLE IF EXISTS `recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendations` (
  `recommendation_id` int NOT NULL AUTO_INCREMENT COMMENT '推荐ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `article_id` int DEFAULT NULL COMMENT '文章ID',
  PRIMARY KEY (`recommendation_id`),
  KEY `user_id` (`user_id`),
  KEY `article_id` (`article_id`),
  CONSTRAINT `recommendations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `recommendations_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `articles` (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendations`
--

LOCK TABLES `recommendations` WRITE;
/*!40000 ALTER TABLE `recommendations` DISABLE KEYS */;
INSERT INTO `recommendations` VALUES (1,1,2),(2,2,3),(3,3,4),(4,4,1);
/*!40000 ALTER TABLE `recommendations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `records_face`
--

DROP TABLE IF EXISTS `records_face`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `records_face` (
  `face_id` int NOT NULL AUTO_INCREMENT COMMENT '表情记录ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `face_imgstr` varchar(100) NOT NULL COMMENT '表情路径',
  `emotion` varchar(10) DEFAULT NULL COMMENT '情绪',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`face_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `records_face_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `records_face`
--

LOCK TABLES `records_face` WRITE;
/*!40000 ALTER TABLE `records_face` DISABLE KEYS */;
INSERT INTO `records_face` VALUES (1,1,'face_image1.jpg','快乐','2024-12-12 15:59:57'),(2,2,'face_image2.jpg','悲伤','2024-12-12 15:59:57'),(3,3,'face_image3.jpg','愤怒','2024-12-12 15:59:57'),(4,4,'face_image4.jpg','惊讶','2024-12-12 15:59:57');
/*!40000 ALTER TABLE `records_face` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `records_text`
--

DROP TABLE IF EXISTS `records_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `records_text` (
  `text_id` int NOT NULL AUTO_INCREMENT COMMENT '文本记录ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `text_content` text NOT NULL COMMENT '文本内容',
  `emotion` varchar(10) DEFAULT NULL COMMENT '情绪',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`text_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `records_text_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `records_text`
--

LOCK TABLES `records_text` WRITE;
/*!40000 ALTER TABLE `records_text` DISABLE KEYS */;
INSERT INTO `records_text` VALUES (1,1,'今天天气真好，心情也跟着愉快起来。','快乐','2024-12-12 15:59:57'),(2,2,'最近工作压力很大，感觉有点疲惫。','悲伤','2024-12-12 15:59:57'),(3,3,'对这件事感到非常不满，需要找人倾诉。','愤怒','2024-12-12 15:59:57'),(4,4,'刚刚得知一个意外的消息，让我很震惊。','惊讶','2024-12-12 15:59:57');
/*!40000 ALTER TABLE `records_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `records_voice`
--

DROP TABLE IF EXISTS `records_voice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `records_voice` (
  `voice_id` int NOT NULL AUTO_INCREMENT COMMENT '语音记录ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `voice_file_path` varchar(255) NOT NULL COMMENT '语音文件路径',
  `emotion` varchar(10) DEFAULT NULL COMMENT '情绪',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`voice_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `records_voice_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `records_voice`
--

LOCK TABLES `records_voice` WRITE;
/*!40000 ALTER TABLE `records_voice` DISABLE KEYS */;
INSERT INTO `records_voice` VALUES (1,1,'voice_file1.wav','快乐','2024-12-12 15:59:57'),(2,2,'voice_file2.wav','悲伤','2024-12-12 15:59:57'),(3,3,'voice_file3.wav','愤怒','2024-12-12 15:59:57'),(4,4,'voice_file4.wav','惊讶','2024-12-12 15:59:57');
/*!40000 ALTER TABLE `records_voice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(20) NOT NULL COMMENT '用户名',
  `nickname` varchar(10) DEFAULT NULL COMMENT '昵称',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `email` varchar(25) DEFAULT NULL COMMENT '电子邮件',
  `avatar` varchar(100) DEFAULT NULL COMMENT '头像地址',
  `sex` varchar(10) DEFAULT NULL COMMENT '性别',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'user1','小明','password123','user1@example.com','avatar1.jpg','男','1990-01-01','2024-12-12 15:59:57','2024-12-12 15:59:57'),(2,'user2','小红','password456','user2@example.com','avatar2.jpg','女','1992-02-02','2024-12-12 15:59:57','2024-12-12 15:59:57'),(3,'user3','小刚','password789','user3@example.com','avatar3.jpg','男','1994-03-03','2024-12-12 15:59:57','2024-12-12 15:59:57'),(4,'user4','小丽','passwordabc','user4@example.com','avatar4.jpg','女','1996-04-04','2024-12-12 15:59:57','2024-12-12 15:59:57');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-14 20:37:28

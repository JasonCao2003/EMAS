package com.xupt.emas.controller;

import com.xupt.emas.pojo.*;
import com.xupt.emas.service.AnalysisServer;
import com.xupt.emas.service.RecordService;
import com.xupt.emas.utils.AliOssUtil;
import com.xupt.emas.utils.ThreadLocalUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Controller
public class RecordController {
    @Resource
    private RecordService recordService;
    @Resource
    private AnalysisServer analysisServer;


    @PostMapping("textRecord")
    public Result<?> textRecord(String text){
        return recordService.Record2Emotion(text, "text", null);
    }

    @PostMapping("faceRecord")
    public Result<?> faceRecord(@RequestParam("image") MultipartFile file) {
        return recordService.Record2Emotion(null, "face", file);
    }

    @PostMapping("voiceRecord")
    public Result<?> voiceRecord(@RequestParam("audio") MultipartFile file) {
        return recordService.Record2Emotion(null, "voice", file);
    }

    // 查询所有文本记录
    @PostMapping("/listTextRecords")
    public Result<?> listTextRecords() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        List<RecordsText> texts = recordService.selectTexts(userid);
        return Result.success(texts);
    }

    // 查询所有表情记录
    @PostMapping("/listFaceRecords")
    public Result<?> listFaceRecords() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        List<RecordsFace> faces = recordService.selectFaces(userid);
        return Result.success(faces);
    }

    // 查询所有语音记录
    @PostMapping("/listVoiceRecords")
    public Result<?> listVoiceRecords() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        List<RecordsVoice> voices = recordService.selectVoices(userid);
        return Result.success(voices);
    }

    // 查询所有分析结果
    @PostMapping("listAnalysis")
    public Result<?> listAnalysis() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        List<AnalysisResults> results = analysisServer.listAnalysis(userid);
        return Result.success(results);
    }

    // 获取情绪统计数据 {emotion:count}
    @PostMapping("/countEmotions")
    public Result<?> getEmotion() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userId = (Integer) map.get("userid");
        List<Map<String, Object>> emotionStats = analysisServer.countEmotions(userId);
        return Result.success(emotionStats);
    }

    // 获取情绪统计数据 {date:{emotion:count}}
    @PostMapping("/getDailyEmotion")
    public Result<?> getDailyEmotion() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userId = (Integer) map.get("userid");
        Map<String, List<Map<String, Object>>> dailyStats = analysisServer.countDailyEmotionsByUser(userId);
        return Result.success(dailyStats);
    }

}

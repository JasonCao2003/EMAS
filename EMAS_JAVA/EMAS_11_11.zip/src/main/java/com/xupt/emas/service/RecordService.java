package com.xupt.emas.service;

import com.xupt.emas.pojo.RecordsFace;
import com.xupt.emas.pojo.RecordsText;
import com.xupt.emas.pojo.RecordsVoice;
import com.xupt.emas.pojo.Result;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


public interface RecordService {
    int addFaceRecord(RecordsFace recordsFace);
    int addVoiceRecord(RecordsVoice recordsVoice);
    int addTextRecord(RecordsText recordsText);
    List<RecordsText> selectTexts(int id);
    List<RecordsVoice> selectVoices(int id);
    List<RecordsFace> selectFaces(int id);
    Result<?> Record2Emotion(String text, String type, MultipartFile file);
}

package com.xupt.emas.service.impl;

import com.xupt.emas.pojo.Result;
import com.xupt.emas.service.SparkService;
import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.UUID;

@Service
public class SparkServiceImpl implements SparkService {
    private static final HttpClient client = HttpClient.newHttpClient();


    @Override
    public String Text2Emo(String text) throws Exception {
        text = "{\"text\": \"" + text + "\"}";
        // 创建 HttpRequest
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://127.0.0.1:5000/classify_text2emo"))
                .header("Content-Type", "application/json; utf-8")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(text))
                .build();
        // 发送请求并读取响应
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        // 返回解码后的响应 --- 获取emotion
        if (response.statusCode() >= 200 && response.statusCode() < 300) {
            return StringEscapeUtils.unescapeJava(response.body());
        } else {
            return "识别失败，状态码: " + response.statusCode();
        }
    }

    @Override
    public String Face2Emo(MultipartFile file) throws Exception {
        Result<?> result = sendMultipartRequest(file,
                "http://127.0.0.1:5000/detect_faceid",
                "image");
        if (result.getCode() != 1) {
            return result.getMessage();
        }
        return null;
    }

    @Override
    public String Voice2Emo(MultipartFile file) throws Exception {
        Result<?> result = sendMultipartRequest(file,
                "http://127.0.0.1:5000/classify_audio2emo",
                "audio");
        if (result.getCode() != 1) {
            return result.getMessage();
        }
        return null;
    }

    @Override
    public String BiometricLogin(String type, MultipartFile file) {
        String url;
        String fieldType;

        if ("face".equals(type)) {
            url = "http://127.0.0.1:5000/detect_faceid";
            fieldType = "image";
        } else if ("voice".equals(type)) {
            url = "http://127.0.0.1:5000/verify_audioid";
            fieldType = "audio";
        } else {
            return "无效的生物识别类型";
        }

        // 重试逻辑
        int attempt = 0;
        int maxRetries = 3;
        Result<?> result;
        while (attempt < maxRetries) {
            try {
                attempt++;
                result = sendMultipartRequest(file, url, fieldType);
                if (result.getCode() == 1) {
                    // 成功时返回用户名  --  提取username
                    return result.getMessage();
                }
            } catch (Exception e) {
                System.err.println("请求失败，第 " + attempt + " 次重试，错误信息：" + e.getMessage());
                if (attempt >= maxRetries) {
                    return "请求失败，最大重试次数已达：" + e.getMessage();
                }
            }
        }
        return "识别失败，超过最大重试次数";
    }


    private Result<?> sendMultipartRequest(MultipartFile file, String url, String fieldName) throws Exception {
        // 生成边界字符串
        String boundary = "Boundary-" + UUID.randomUUID();
        // 构建请求体
        StringBuilder bodyBuilder = new StringBuilder();
        bodyBuilder.append("--").append(boundary).append("\r\n")
                .append("Content-Disposition: form-data; name=\"").append(fieldName).append("\"; filename=\"")
                .append(file.getOriginalFilename()).append("\"\r\n")
                .append("Content-Type: ").append(file.getContentType()).append("\r\n\r\n");
        // 将文件数据转为字节数组并附加到请求体
        byte[] fileBytes = file.getBytes();
        bodyBuilder.append(new String(fileBytes)).append("\r\n")
                .append("--").append(boundary).append("--\r\n");
        // 创建HttpRequest对象
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(url))
                .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(HttpRequest.BodyPublishers.ofString(bodyBuilder.toString()))
                .build();
        // 发送请求并获取响应
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        // 返回响应体内容 ---  获取emotion
        if (response.statusCode() >= 200 && response.statusCode() < 300) {
            return Result.success(response.body());
        } else {
            return Result.error("识别失败，状态码: " + response.statusCode());
        }
    }

}

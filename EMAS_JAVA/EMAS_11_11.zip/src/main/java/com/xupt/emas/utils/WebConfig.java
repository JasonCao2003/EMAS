package com.xupt.emas.utils;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    // 注册拦截器
    @Resource
    private LoginInterceptor loginInterceptor;

    // 方法白名单
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(loginInterceptor).excludePathPatterns(
                "/login/pwdLogin",
                "/login/faceLogin",
                "/login/voiceLogin",
                "/login/emailLogin",
                "/login/sendValidation",
                "/user/register");
    }
}

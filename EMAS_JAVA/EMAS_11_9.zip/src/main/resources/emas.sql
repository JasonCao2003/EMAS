DROP DATABASE IF EXISTS emas;
CREATE DATABASE emas charset utf8;
USE emas;

-- 用于存储用户信息
CREATE TABLE Users
(
    user_id    INT PRIMARY KEY AUTO_INCREMENT COMMENT '用户ID',
    username   VARCHAR(20)  NOT NULL COMMENT '用户名',
    nickname   VARCHAR(10) COMMENT '昵称',
    password   VARCHAR(100) NOT NULL COMMENT '密码',
    email      VARCHAR(25) COMMENT '电子邮件',
    avatar     VARCHAR(100) COMMENT '头像地址',
    sex        VARCHAR(10) COMMENT '性别',
    birthday   DATE COMMENT '生日',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间'
);


-- 用于存储用户的文本输入记录
CREATE TABLE Records_Text
(
    text_id      INT PRIMARY KEY AUTO_INCREMENT COMMENT '文本记录ID',    -- 文本记录的唯一标识
    user_id      INT COMMENT '用户ID',                                   -- 与用户表关联的用户ID
    text_content TEXT NOT NULL COMMENT '文本内容',                       -- 用户的文本内容
    emotion      VARCHAR(10) COMMENT '情绪',                             -- 用户的情绪
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间', -- 文本记录创建时间
    FOREIGN KEY (user_id) REFERENCES Users (user_id)                     -- 外键关联用户表         -- 外键关联情绪表
);

-- 用于存储用户的脸部表情记录
CREATE TABLE Records_Face
(
    face_id     INT PRIMARY KEY AUTO_INCREMENT COMMENT '表情记录ID',    -- 表情记录的唯一标识
    user_id     INT COMMENT '用户ID',                                   -- 与用户表关联的用户ID
    face_imgstr VARCHAR(100) NOT NULL COMMENT '表情路径',               -- 用户的表情
    emotion     VARCHAR(10) COMMENT '情绪',                             -- 用户的情绪
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间', -- 表情记录创建时间
    FOREIGN KEY (user_id) REFERENCES Users (user_id)                    -- 外键关联用户表        -- 外键关联情绪表
);

-- 用于存储用户的语音输入记录
CREATE TABLE Records_Voice
(
    voice_id        INT PRIMARY KEY AUTO_INCREMENT COMMENT '语音记录ID',    -- 语音记录的唯一标识
    user_id         INT COMMENT '用户ID',                                   -- 与用户表关联的用户ID
    voice_file_path VARCHAR(255) NOT NULL COMMENT '语音文件路径',           -- 存储语音文件的路径
    emotion         VARCHAR(10) COMMENT '情绪',                             -- 用户情绪
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间', -- 语音记录创建时间
    FOREIGN KEY (user_id) REFERENCES Users (user_id)                        -- 外键关联用户表            -- 外键关联情绪表
);

-- 用于存储情绪分析的结果
CREATE TABLE Analysis_Results
(
    analysis_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '分析结果ID',        -- 分析结果的唯一标识
    user_id     INT COMMENT '用户ID',                                       -- 与用户表关联的用户ID
    source_type ENUM ('text', 'face', 'voice') NOT NULL COMMENT '来源类型', -- 情绪分析的来源类型：文本、表情、语音
    source_id   INT COMMENT '来源记录ID',                                   -- 对应文本、表情或语音的记录ID
    emotion     VARCHAR(10) COMMENT '情绪',                                 -- 用户情绪
    confidence  FLOAT COMMENT '置信度',                                     -- 情绪分析的置信度
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',     -- 分析结果创建时间
    FOREIGN KEY (user_id) REFERENCES Users (user_id)                        -- 外键关联用户表               -- 外键关联情绪表
);


-- 存储文章的基本信息
CREATE TABLE Articles
(
    article_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '文章ID',
    title      VARCHAR(255) NOT NULL COMMENT '文章标题',
    content    TEXT         NOT NULL COMMENT '文章内容',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
);


-- 用于存储文件推荐信息
CREATE TABLE Recommendations
(
    recommendation_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '推荐ID',
    user_id           INT COMMENT '用户ID',
    article_id        INT COMMENT '文章ID',
    FOREIGN KEY (user_id) REFERENCES Users (user_id),
    FOREIGN KEY (article_id) REFERENCES Articles (article_id)
);


-- 用于存储用户点踩信息
CREATE TABLE Feedbacks
(
    feedback_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '反馈ID',
    user_id     INT COMMENT '用户ID',
    article_id  INT COMMENT '文章ID',
    feedback    ENUM ('like', 'dislike') COMMENT '反馈类型',
    FOREIGN KEY (user_id) REFERENCES Users (user_id),
    FOREIGN KEY (article_id) REFERENCES Articles (article_id)
);


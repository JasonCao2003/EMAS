package com.xupt.emas.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xupt.emas.pojo.Articles;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ArticleMapper extends BaseMapper<Articles> {

    @Select("SELECT * FROM Articles ORDER BY RAND() LIMIT 10")
    List<Articles> getRandomArticles();

    @Select("SELECT a.title, a.content " +
            "FROM Articles a " +
            "JOIN Feedbacks f ON a.article_id = f.article_id " +
            "WHERE f.user_id = #{userId} AND f.feedback = 'like'")
    List<Articles> selectLikedArticlesByUserId(@Param("userId") int userId);
}

package com.xupt.emas.controller;

import com.xupt.emas.pojo.*;
import com.xupt.emas.service.AnalysisServer;
import com.xupt.emas.service.RecordService;
import com.xupt.emas.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Controller
public class RecordController {
    @Resource
    private RecordService recordService;
    @Resource
    private AnalysisServer analysisServer;


    @PostMapping("textRecord")
    public Result<?> TextRecord(String text) throws Exception {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        Date now = new Date();
        // text2emo
        String emotion = analysisServer.textEmotionAnalysis(text);
        RecordsText recordsText = new RecordsText(0, userid, text, emotion, now);
        int recordId = recordService.addTextRecord(recordsText);

        AnalysisResults analysisResults = new AnalysisResults(0, userid, "text", recordId, emotion, 1, now);
        analysisServer.addAnalysis(analysisResults);
        return Result.success();
    }

    @PostMapping("faceRecord")
    public Result<?> FaceRecord(@RequestParam("image") MultipartFile file) {
        if (file.isEmpty()) {
            return Result.error("文件为空");
        }
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        String username = (String) map.get("username");
        try {
            String filePath = saveFile(username, "image", file);
            // face2emo
            String emotion = analysisServer.faceEmotionAnalysis(file);
            Date now = new Date();
            RecordsFace recordsFace = new RecordsFace(0, userid, filePath, emotion, now);
            int recordId = recordService.addFaceRecord(recordsFace);
            AnalysisResults analysisResults = new AnalysisResults(0, userid, "face", recordId, emotion, 1, now);
            analysisServer.addAnalysis(analysisResults);
            return Result.success();
        } catch (IOException e) {
            e.printStackTrace();
            return Result.error(e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @PostMapping("voiceRecord")
    public Result<?> VoiceRecord(@RequestParam("audio") MultipartFile file) {
        if (file.isEmpty()) {
            return Result.error("文件为空");
        }
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        String username = (String) map.get("username");
        try {
            String filePath = saveFile(username, "audio", file);
            // audio2emo
            String emotion = analysisServer.voiceEmotionAnalysis(file);
            Date now = new Date();
            RecordsVoice record = new RecordsVoice(0, userid, filePath, emotion, now);
            int recordId = recordService.addVoiceRecord(record);
            AnalysisResults analysisResults = new AnalysisResults(0, userid, "voice", recordId, emotion, 1, now);
            analysisServer.addAnalysis(analysisResults);
            return Result.success();
        } catch (IOException e) {
            e.printStackTrace();
            return Result.error(e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @PostMapping("listAnalysis")
    public Result<?> listAnalysis() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        List<AnalysisResults> results = analysisServer.listAnalysis(userid);
        return Result.success(results);
    }


    @PostMapping("/listTextRecords")
    public Result<?> listTextRecords() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        List<RecordsText> texts = recordService.selectTexts(userid);
        return Result.success(texts);
    }

    @PostMapping("/listFaceRecords")
    public Result<?> listFaceRecords() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        List<RecordsFace> faces = recordService.selectFaces(userid);
        return Result.success(faces);
    }

    @PostMapping("/listVoiceRecords")
    public Result<?> listVoiceRecords() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        List<RecordsVoice> voices = recordService.selectVoices(userid);
        return Result.success(voices);
    }


    // 获取情绪统计数据
    @PostMapping("/countEmotions")
    public Result<?> getEmotionStatistics() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userId = (Integer) map.get("userid");
        List<Map<String, Object>> emotionStats = analysisServer.countEmotions(userId);
        return Result.success(emotionStats);
    }

    @PostMapping("/countEmotionsByDate")
    public Result<?> getDailyEmotionStatistics() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userId = (Integer) map.get("userid");
        Map<String, List<Map<String, Object>>> dailyStats = analysisServer.countDailyEmotionsByUser(userId);
        return Result.success(dailyStats);
    }


    @Value("${file.upload-path}")
    private String basePath;

    public String saveFile(String username, String type, MultipartFile file) throws IOException {
        String extension = type.equals("image") ? ".jpg" : ".mp3";
        String filename = UUID.randomUUID() + extension;
        String directoryPath = basePath + File.separator + type + File.separator + username;
        File directory = new File(directoryPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        File dest = new File(directory, filename);
        file.transferTo(dest);
        return directoryPath + File.separator + filename;
    }
}

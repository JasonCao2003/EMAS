package com.xupt.emas.service.impl;

import com.xupt.emas.mapper.ArticleMapper;
import com.xupt.emas.mapper.FeedbackMapper;
import com.xupt.emas.mapper.RecommendationMapper;
import com.xupt.emas.pojo.Articles;
import com.xupt.emas.pojo.Feedbacks;
import com.xupt.emas.pojo.Recommendations;
import com.xupt.emas.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArticleServiceImpl implements ArticleService {

    @Autowired
    private ArticleMapper articleMapper;

    @Autowired
    private RecommendationMapper RecommendationMapper;

    @Autowired
    private FeedbackMapper feedbackMapper;

    @Override
    public List<Articles> getRandomArticles() {
        return articleMapper.getRandomArticles();
    }

    @Override
    public List<Recommendations> recommendArticles(int userId) {
        return RecommendationMapper.selectRecommendations(userId);
    }

    @Override
    public void submitFeedback(Feedbacks feedbacks) {
        feedbackMapper.insert(feedbacks);
    }

    @Override
    public List<Articles> ListLikedArticles(int userId) {
        return articleMapper.selectLikedArticlesByUserId(userId);
    }
}

package com.xupt.emas.service;

import com.xupt.emas.pojo.AnalysisResults;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

public interface AnalysisServer {

    void addAnalysis(AnalysisResults analysisResults);

    String textEmotionAnalysis(String text) throws Exception;

    String voiceEmotionAnalysis(MultipartFile file) throws Exception;

    String faceEmotionAnalysis(MultipartFile file) throws Exception;

    List<AnalysisResults> listAnalysis(int userId);

    List<Map<String, Object>> countEmotions(int userId);

    Map<String, List<Map<String, Object>>> countDailyEmotionsByUser(int userId);
}

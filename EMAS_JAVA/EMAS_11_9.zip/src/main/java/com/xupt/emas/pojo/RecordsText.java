package com.xupt.emas.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@AllArgsConstructor
public class RecordsText {
    private int textId;  // 文本记录ID
    private int userId;        // 用户ID
    private String textContent; // 文本内容
    private String emotion;     // 情绪
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdAt;    // 创建时间
}

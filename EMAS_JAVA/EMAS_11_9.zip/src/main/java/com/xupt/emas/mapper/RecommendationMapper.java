package com.xupt.emas.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xupt.emas.pojo.Recommendations;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RecommendationMapper extends BaseMapper<Recommendations> {
    @Select("SELECT * FROM Recommendations WHERE user_id = #{userId}")
    List<Recommendations> selectRecommendations(int userId);
}

package com.xupt.emas.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Feedbacks {
    private Integer feedbackId; // 反馈ID
    private Integer userId; // 用户ID
    private Integer articleId; // 文章ID
    private String feedback; // 反馈类型 ('like' 或 'dislike')
}

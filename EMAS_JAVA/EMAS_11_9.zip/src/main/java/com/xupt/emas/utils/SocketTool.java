package com.xupt.emas.utils;

import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.locks.ReentrantLock;

public class SocketTool {

    private static final String SERVER_ADDRESS = "127.0.0.1";
    private static final int SERVER_PORT = 8888;
    private final ReentrantLock lock = new ReentrantLock();
    private final boolean stopSending = false;
    private Socket socket;

    private void createSocket() {
        try {
            socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

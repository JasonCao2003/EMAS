package com.xupt.emas.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@AllArgsConstructor
public class RecordsFace {
    private int FaceId; // 表情记录ID
    private int userId;        // 用户ID
    private String faceImgstr; // 表情图片路径
    private String emotion;     // 情绪ID
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdAt;    // 创建时间
}

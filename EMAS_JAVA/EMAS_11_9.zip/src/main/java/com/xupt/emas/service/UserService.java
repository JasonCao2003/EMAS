package com.xupt.emas.service;

import com.xupt.emas.pojo.Users;


public interface UserService {
    void addUser(String username, String password);

    void deleteUser(int userId);

    void updateUser(Users user);

    void updateAvatar(String avatarUrl, Integer userid);

    void updatePwd(String password, Integer userid);

    Users getUserById(int userId);

    Users getUserByUsername(String username);

    Users getUserByEmail(String email);

}


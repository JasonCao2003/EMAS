package com.xupt.emas.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xupt.emas.pojo.RecordsText;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RecordTextMapper extends BaseMapper<RecordsText> {
    @Select("SELECT * FROM Records_Text WHERE user_id = #{userId}")
    List<RecordsText> selectByUserId(int userId);
}

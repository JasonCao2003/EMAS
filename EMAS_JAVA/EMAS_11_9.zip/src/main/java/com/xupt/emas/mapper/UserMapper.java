package com.xupt.emas.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xupt.emas.pojo.Users;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface UserMapper extends BaseMapper<Users> {

    @Update("update users set email=#{email}, nickname=#{nickname}, sex=#{sex}, birthday=#{birthday}, updated_at=now() where user_id=#{userId}")
    void updateUser(Users user);

    @Update("update users set avatar=#{avatarUrl}, updated_at=now() where user_id=#{userid}")
    void updateAvatar(String avatarUrl, Integer userid);

    @Update("update users set password=#{password}, updated_at=now() where user_id=#{userid}")
    void updatePwd(String password, Integer userid);
}

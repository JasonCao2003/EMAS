package com.xupt.emas.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@AllArgsConstructor
public class RecordsVoice {
    private int voiceId; // 语音记录ID
    private int userId;        // 用户ID
    private String voiceFilePath; // 语音文件路径
    private String emotion;     // 情绪
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdAt;    // 创建时间
}

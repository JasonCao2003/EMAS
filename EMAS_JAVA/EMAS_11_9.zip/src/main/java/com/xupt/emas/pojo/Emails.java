package com.xupt.emas.pojo;


import lombok.Data;

import javax.validation.constraints.Pattern;

@Data
public class Emails {

    @Pattern(regexp = "^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$", message = "邮箱格式不正确")
    private String email;

    @Pattern(regexp = "^\\S{0,6}$", message = "验证码长度不能超过3字符")
    private String code;
}

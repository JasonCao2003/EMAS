package com.xupt.emas.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xupt.emas.pojo.AnalysisResults;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface AnalysisResultsMapper extends BaseMapper<AnalysisResults> {

    @Select("SELECT * FROM Analysis_Results WHERE user_id = #{userId}")
    List<AnalysisResults> selectByUserId(int userId);

    @Select("SELECT emotion, COUNT(*) AS emotion_count " +
            "FROM Analysis_Results " +
            "WHERE user_id = #{userId} " +
            "GROUP BY emotion")
    List<Map<String, Object>> countEmotionsByUser(@Param("userId") int userId);

    @Select("SELECT DATE(created_at) AS date, emotion, COUNT(*) AS emotion_count " +
            "FROM Analysis_Results " +
            "WHERE user_id = #{userId} " +
            "AND created_at >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH) " +
            "GROUP BY DATE(created_at), emotion " +
            "ORDER BY date ")
    List<Map<String, Object>> countDailyEmotionsByUser(@Param("userId") int userId);
}

package com.xupt.emas.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@AllArgsConstructor
public class AnalysisResults {
    private int analysisId;         // 分析结果ID
    private int userId;             // 用户ID
    private String sourceType;      // 来源类型（text, emoji, voice）
    private int sourceId;           // 来源记录ID
    private String emotion;            // 情绪
    private float confidence;       // 置信度
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createdAt;         // 创建时间
}

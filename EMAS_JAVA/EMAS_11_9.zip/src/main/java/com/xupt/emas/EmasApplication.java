package com.xupt.emas;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@MapperScan("com.xupt.emas.mapper")

@SpringBootApplication
public class EmasApplication {


    public static void main(String[] args) {
        SpringApplication.run(EmasApplication.class, args);
        System.out.println("项目已启动...");
    }

}

package com.xupt.emas.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xupt.emas.pojo.RecordsFace;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RecordFaceMapper extends BaseMapper<RecordsFace> {
    @Select("SELECT * FROM Records_Face WHERE user_id = #{userId}")
    List<RecordsFace> selectByUserId(int userId);
}

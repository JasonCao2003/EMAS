package com.xupt.emas.service.impl;

import com.xupt.emas.mapper.AnalysisResultsMapper;
import com.xupt.emas.pojo.AnalysisResults;
import com.xupt.emas.service.AnalysisServer;
import com.xupt.emas.service.SparkService;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AnalysisServerImpl implements AnalysisServer {

    @Resource
    private AnalysisResultsMapper analysisResultsMapper;
    @Resource
    private SparkService sparkService;

    @Override
    public List<AnalysisResults> listAnalysis(int userId) {
        return analysisResultsMapper.selectByUserId(userId);
    }

    @Override
    public void addAnalysis(AnalysisResults analysisResults) {
        analysisResultsMapper.insert(analysisResults);
    }

    @Override
    public String textEmotionAnalysis(String text) throws Exception {
        return sparkService.Text2Emo(text);
    }

    @Override
    public String voiceEmotionAnalysis(MultipartFile file) throws Exception {
        return sparkService.Voice2Emo(file);
    }

    @Override
    public String faceEmotionAnalysis(MultipartFile file) throws Exception {
        return sparkService.Face2Emo(file);
    }

    @Override
    public List<Map<String, Object>> countEmotions(int userId) {
        return analysisResultsMapper.countEmotionsByUser(userId);
    }

    @Override
    public Map<String, List<Map<String, Object>>> countDailyEmotionsByUser(int userId) {
        List<Map<String, Object>> flatData = analysisResultsMapper.countDailyEmotionsByUser(userId);
        Map<String, List<Map<String, Object>>> nestedResult = new HashMap<>();
        for (Map<String, Object> record : flatData) {
            String date = record.get("date").toString();
            Map<String, Object> emotionData = new HashMap<>();
            emotionData.put("emotion", record.get("emotion"));
            emotionData.put("emotion_count", record.get("emotion_count"));
            nestedResult.computeIfAbsent(date, k -> new ArrayList<>()).add(emotionData);
        }
        return nestedResult;
    }
}

package com.xupt.emas.service;

import org.springframework.web.multipart.MultipartFile;

public interface SparkService {
    String Text2Emo(String text) throws Exception;

    String Face2Emo(MultipartFile file) throws Exception;

    String Voice2Emo(MultipartFile file) throws Exception;

    String BiometricLogin(String type, MultipartFile file);
}

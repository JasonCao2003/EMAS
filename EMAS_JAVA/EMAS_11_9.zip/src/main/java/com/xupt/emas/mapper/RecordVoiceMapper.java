package com.xupt.emas.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xupt.emas.pojo.RecordsVoice;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RecordVoiceMapper extends BaseMapper<RecordsVoice> {
    @Select("SELECT * FROM records_voice WHERE user_id = #{userId}")
    List<RecordsVoice> selectByUserId(int userId);
}

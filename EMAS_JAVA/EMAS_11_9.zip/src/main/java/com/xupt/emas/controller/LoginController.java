package com.xupt.emas.controller;


import com.xupt.emas.pojo.Emails;
import com.xupt.emas.pojo.Result;
import com.xupt.emas.pojo.Users;
import com.xupt.emas.service.SparkService;
import com.xupt.emas.service.UserService;
import com.xupt.emas.utils.JwtUtil;
import com.xupt.emas.utils.MailTool;
import com.xupt.emas.utils.Md5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@RestController
@RequestMapping("/login")
public class LoginController {
    @Resource
    private UserService userService;
    @Resource
    private MailTool mailTool;
    @Resource
    private SparkService sparkService;
    @Autowired
    private StringRedisTemplate redisTemplate;

    @PostMapping("/pwdLogin")
    public Result<?> login(@Valid @RequestBody Users u) {
        Users user = userService.getUserByUsername(u.getUsername());
        if (user != null) {
            if (Md5Util.checkPassword(u.getPassword(), user.getPassword())) {
                return getToken(u.getUsername());
            } else {
                return Result.error("密码错误");
            }
        }
        return Result.error("用户不存在");
    }

    @PostMapping("/faceLogin")
    public Result<?> faceLogin(@RequestParam("image") MultipartFile file) throws IOException {
        String username = sparkService.BiometricLogin("face", file);
        if (username == null) {
            return Result.error("未识别成功，请等待");
        }
        return getToken(username);
    }

    @PostMapping("/voiceLogin")
    public Result<?> voiceLogin(@RequestParam("audio") MultipartFile file) throws IOException {
        String username = sparkService.BiometricLogin("voice", file);
        if (username == null) {
            return Result.error("未识别成功，请等待");
        }
        return getToken(username);
    }

    @PostMapping("emailLogin")
    public Result<?> emailLogin(@Valid @RequestBody Emails em) {
        Users user = userService.getUserByEmail(em.getEmail());
        if (user != null) {
            ValueOperations<String, String> operator = redisTemplate.opsForValue();
            if ((em.getCode()).equals(operator.get(em.getEmail()))) {
                return getToken(user.getUsername());
            }
            return Result.error("验证码错误");
        }
        return Result.error("邮箱未验证或绑定");
    }

    @PostMapping("sendValidation")
    public Result<?> SendValidation(@Valid @RequestBody Emails em) {
        Users user = userService.getUserByEmail(em.getEmail());
        if (user != null) {
            return mailTool.SendValidation(em.getEmail());
        }
        return Result.error("此邮箱未绑定或者未注册");
    }

    private Result<?> getToken(String username) {
        Users user = userService.getUserByUsername(username);
        if (user != null) {
            Map<String, Object> claims = new HashMap<>();
            claims.put("userid", user.getUserId());
            claims.put("username", username);
            String token = JwtUtil.genToken(claims);
            return Result.success(token);
        } else {
            return Result.error("登录失败");
        }
    }
}

package com.xupt.emas.pojo;

import lombok.Data;

@Data
public class Recommendations {
    private Integer recommendationId; // 推荐ID
    private Integer userId; // 用户ID
    private Integer articleId; // 文章ID
}

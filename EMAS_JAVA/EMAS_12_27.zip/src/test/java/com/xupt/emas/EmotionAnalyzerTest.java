package com.xupt.emas;

import com.xupt.emas.service.SparkService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;

import java.io.FileInputStream;

@SpringBootTest
public class EmotionAnalyzerTest {

    @Autowired
    private SparkService sparkService;

    @Test
    public void testText2Emo() {
        String inputText = "今天天气真好啊！";
        try {
            String result = sparkService.Text2Emo(inputText);
            System.out.println("情绪识别结果: " + result);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    @Test
    public void testFaceEmotionAnalysis() {
        String filePath = "C://Users/27641/Desktop/情绪助手/TestFile/image.jpg";
        try (FileInputStream fileInputStream = new FileInputStream(filePath)) {
            MockMultipartFile mockFile = new MockMultipartFile("file", "image.jpg", "image/jpeg", fileInputStream);
            String result = sparkService.Face2Emo(mockFile);
            System.out.println(result);
        } catch (Exception e) {
            System.out.println("识别失败");
        }
    }


    @Test
    public void testAnalyzeAudioEmotion() {
        // 本地音频文件路径
        String filePath = "C://Users/27641/Desktop/情绪助手/TestFile/audio.wav";
        try (FileInputStream fileInputStream = new FileInputStream(filePath)) {
            MockMultipartFile mockFile = new MockMultipartFile("file", "audio.wav", "audio/wav", fileInputStream);
            String result = sparkService.Voice2Emo(mockFile);
            System.out.println(result);
        } catch (Exception e) {
            System.out.println("识别失败");
        }
    }


    @Test
    public void faceLoginTest() {
        String filePath = "C://Users/27641/Desktop/情绪助手/TestFile/image.jpg";
        try (FileInputStream fileInputStream = new FileInputStream(filePath)) {
            MockMultipartFile mockFile = new MockMultipartFile("file", "image.jpg", "image/jpeg", fileInputStream);
            String result = sparkService.Face2User(mockFile);
            System.out.println(result);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("识别失败");
        }
    }


    @Test
    public void VoiceLoginTest() {
        String filePath = "C://Users/27641/Desktop/情绪助手/TestFile/audio2.wav";
        try (FileInputStream fileInputStream = new FileInputStream(filePath)) {
            MockMultipartFile mockFile = new MockMultipartFile("file", "audio2.wav", "audio/wav", fileInputStream);
//            MockMultipartFile mockFile = new MockMultipartFile("file", "speaker2.mp3", "audio/mp3", fileInputStream);
            String result = sparkService.Voice2User(mockFile);
            System.out.println(result);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("识别失败");
        }
    }


}

package com.xupt.emas.configs;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

// 网络配置类
@Configuration
public class WebConfig implements WebMvcConfigurer {

    // 注册拦截器
    @Resource
    private Interceptor interceptor;

    // 过滤白名单
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(interceptor).excludePathPatterns(
                "/login/pwdLogin",
                "/login/faceLogin",
                "/login/voiceLogin",
                "/login/emailLogin",
                "/login/sendValidation",
                "/user/register");
    }

    // 配置跨源资源共享
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOriginPatterns("*")
                .allowedOrigins("http://localhost:9094")
                .allowedMethods("GET", "HEAD", "POST", "PUT", "DELETE", "OPTIONS")
                .allowCredentials(true)
                .maxAge(3600)
                .allowedHeaders("*")
                .exposedHeaders("Authorization");
    }
}

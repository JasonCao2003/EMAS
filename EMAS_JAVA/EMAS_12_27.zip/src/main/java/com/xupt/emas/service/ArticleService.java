package com.xupt.emas.service;

import com.xupt.emas.pojo.Articles;
import com.xupt.emas.pojo.Feedbacks;
import com.xupt.emas.pojo.Recommendations;

import javax.validation.Valid;
import java.util.List;


public interface ArticleService {

    // 获取随机十条文章
    List<Articles> getRandomArticles();

    // 推荐文章给用户
    List<Recommendations> recommendArticles(int userId);

    // 用户对文章进行点踩
    void submitFeedback(Feedbacks feedbacks);

    // 选择用户点赞过的文章
    List<Articles> ListLikedArticles(int userId);

    void disLike(@Valid Feedbacks fd);
}

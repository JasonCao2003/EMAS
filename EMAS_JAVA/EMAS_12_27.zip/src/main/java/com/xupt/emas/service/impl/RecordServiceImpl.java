package com.xupt.emas.service.impl;

import com.xupt.emas.mapper.RecordFaceMapper;
import com.xupt.emas.mapper.RecordTextMapper;
import com.xupt.emas.mapper.RecordVoiceMapper;
import com.xupt.emas.pojo.AnalysisResults;
import com.xupt.emas.pojo.RecordsFace;
import com.xupt.emas.pojo.RecordsText;
import com.xupt.emas.pojo.RecordsVoice;
import com.xupt.emas.service.AnalysisServer;
import com.xupt.emas.service.RecordService;
import com.xupt.emas.utils.AliOssUtil;
import com.xupt.emas.utils.ThreadLocalUtil;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;


@Service
public class RecordServiceImpl implements RecordService {
    @Resource
    private RecordFaceMapper recordFaceMapper;
    @Resource
    private RecordTextMapper recordTextMapper;
    @Resource
    private RecordVoiceMapper recordVoiceMapper;
    @Resource
    private AnalysisServer analysisServer;


    @Override
    public int addFaceRecord(RecordsFace recordsFace) {
        recordFaceMapper.insert(recordsFace);
        return recordsFace.getFaceId();
    }

    @Override
    public int addVoiceRecord(RecordsVoice recordsVoice) {
        recordVoiceMapper.insert(recordsVoice);
        return recordsVoice.getVoiceId();
    }

    @Override
    public int addTextRecord(RecordsText recordsText) {
        try {
            recordTextMapper.insert(recordsText);
            return recordsText.getTextId();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return 0;
    }

    @Override
    public List<RecordsText> selectTexts(int id) {
        return recordTextMapper.selectByUserId(id);
    }

    @Override
    public List<RecordsVoice> selectVoices(int id) {
        return recordVoiceMapper.selectByUserId(id);
    }

    @Override
    public List<RecordsFace> selectFaces(int id) {
        return recordFaceMapper.selectByUserId(id);
    }

    public String Record2Emotion(String text, String type, MultipartFile file){
        try{
            Map<String, Object> map = ThreadLocalUtil.get();
            Integer userid = (Integer) map.get("userid");
            Date now = new Date();
            String emotion;
            int recordId;
            String filePath;
            switch (type) {
                case "text":
                    emotion = analysisServer.textEmotionAnalysis(text);
                    RecordsText recordsText = new RecordsText(0, userid, text, emotion, now);
                    recordId = addTextRecord(recordsText);
                    break;
                case "face":
                    filePath = AliOssUtil.UploadFile(UUID.randomUUID() + ".jpg", file.getInputStream());
                    emotion = analysisServer.faceEmotionAnalysis(file);
                    RecordsFace recordsFace = new RecordsFace(0, userid, filePath, emotion, now);
                    recordId = addFaceRecord(recordsFace);
                    break;
                case "voice":
                    filePath = AliOssUtil.UploadFile(UUID.randomUUID() + ".mp3", file.getInputStream());
                    emotion = analysisServer.voiceEmotionAnalysis(file);
                    RecordsVoice recordsVoice = new RecordsVoice(0, userid, filePath, emotion, now);
                    recordId = addVoiceRecord(recordsVoice);
                    break;
                default:
                    return null;
            }
            AnalysisResults analysisResults = new AnalysisResults(0, userid, type, recordId, emotion, 1, now);
            analysisServer.addAnalysis(analysisResults);
            return emotion;
        }catch (Exception e){
            System.out.println("###################"+e.getMessage());
        }
        return null;
    }
}

package com.xupt.emas.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xupt.emas.pojo.AnalysisResults;
import com.xupt.emas.pojo.Feedbacks;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface FeedbackMapper extends BaseMapper<Feedbacks> {

    @Update("UPDATE Feedbacks SET feedback = 'dislike' WHERE article_id = #{id}")
    void dislike(@Param("id") int id);
}

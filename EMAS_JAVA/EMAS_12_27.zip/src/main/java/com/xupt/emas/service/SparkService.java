package com.xupt.emas.service;

import com.xupt.emas.pojo.Result;
import org.springframework.web.multipart.MultipartFile;

public interface SparkService {
    String Text2Emo(String text) throws Exception;

    String Face2Emo(MultipartFile file) throws Exception;

    String Voice2Emo(MultipartFile file) throws Exception;

    String Face2User(MultipartFile file) throws Exception;

    String Voice2User(MultipartFile file) throws Exception;

    Result<?> UploadFaceInfo(MultipartFile file, String username) throws Exception;

//    Result<?> UploadVoiceInfo(MultipartFile file, String username) throws Exception;

    Result<?> UploadVoiceInfo(MultipartFile file) throws Exception;

    Result<?> UploadVoiceInfo(MultipartFile file, String username) throws Exception;
}

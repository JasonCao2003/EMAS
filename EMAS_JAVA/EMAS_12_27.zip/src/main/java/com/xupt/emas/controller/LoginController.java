package com.xupt.emas.controller;


import com.xupt.emas.pojo.Emails;
import com.xupt.emas.pojo.Result;
import com.xupt.emas.pojo.Users;
import com.xupt.emas.service.SparkService;
import com.xupt.emas.service.UserService;
import com.xupt.emas.utils.JwtUtil;
import com.xupt.emas.utils.MailUtil;
import com.xupt.emas.utils.Md5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;


@RestController
@RequestMapping("/login")
public class LoginController {
    @Resource
    private UserService userService;
    @Resource
    private MailUtil mailUtil;
    @Resource
    private SparkService sparkService;
    @Autowired
    private StringRedisTemplate redisTemplate;

    // 密码登录
    @PostMapping("/pwdLogin")
    public Result<?> pwdLogin(@Valid @RequestBody Users u) {
        Users user = userService.getUserByUsername(u.getUsername());
        if (user == null) return Result.error("用户不存在");
        boolean validPassword = Md5Util.checkPassword(u.getPassword(), user.getPassword());
        return validPassword ? getToken(user) : Result.error("密码错误");
    }

    // 人脸登录
    @PostMapping("/faceLogin")
    public Result<?> faceLogin(@RequestParam("image") MultipartFile file) throws Exception {
        String username = sparkService.Face2User(file);
        Users user = userService.getUserByUsername(username);
        return user != null ? getToken(user) : Result.error("您的信息未录入或未注册");
    }

    // 声纹登录
    @PostMapping("/voiceLogin")
    public Result<?> voiceLogin(@RequestParam("audio") MultipartFile file) throws Exception {
        try {
            String username = sparkService.Voice2User(file);
            Users user = userService.getUserByUsername(username);
            return user != null ? getToken(user) : Result.error("您的信息未录入或未注册");
        }catch (Exception e){
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }
    // 邮箱登录
    @PostMapping("/emailLogin")
    public Result<?> emailLogin(@Valid @RequestBody Emails em) {
        ValueOperations<String, String> operator = redisTemplate.opsForValue();
        Users user = userService.getUserByEmail(em.getEmail());
        if (user == null) return Result.error("邮箱未验证或绑定");
        boolean validCode = em.getCode().equals(operator.get(em.getEmail()));
        return validCode ? getToken(user) : Result.error("验证码错误");
    }

    // 发送验证码 （邮箱验证用）
    @PostMapping("/sendValidation")
    public Result<?> sendValidation(@Valid @RequestBody Emails em) {
        Users user = userService.getUserByEmail(em.getEmail());
        return user != null ? mailUtil.SendValidation(em.getEmail()) : Result.error("此邮箱未绑定或者未注册");
    }

    // 获取JWT校验码
    private Result<?> getToken(Users user) {
        // 生成token
        Map<String, Object> claims = new HashMap<>();
        claims.put("userid", user.getUserId());
        claims.put("username", user.getUsername());
        String token = JwtUtil.genToken(claims);
        // 把token存储到redis中
        ValueOperations<String, String> operator = redisTemplate.opsForValue();
        operator.set(token, token, 12, TimeUnit.HOURS);
        // 把token返回给前端
        return Result.success(token);
    }
}


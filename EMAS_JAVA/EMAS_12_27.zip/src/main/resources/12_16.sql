-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: emas
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `analysis_results`
--

drop database if exists emas;
create database emas;
use emas;

DROP TABLE IF EXISTS `analysis_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `analysis_results` (
  `analysis_id` int NOT NULL AUTO_INCREMENT COMMENT '分析结果ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `source_type` enum('text','face','voice') NOT NULL COMMENT '来源类型',
  `source_id` int DEFAULT NULL COMMENT '来源记录ID',
  `emotion` varchar(10) DEFAULT NULL COMMENT '情绪',
  `confidence` float DEFAULT NULL COMMENT '置信度',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`analysis_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `analysis_results_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analysis_results`
--

LOCK TABLES `analysis_results` WRITE;
/*!40000 ALTER TABLE `analysis_results` DISABLE KEYS */;
INSERT INTO `analysis_results` VALUES (1,1,'text',0,'高兴',1,'2024-11-25 10:01:20'),(2,1,'text',0,'高兴',1,'2024-11-25 10:03:21'),(3,1,'text',0,'高兴',1,'2024-11-25 10:05:02'),(4,1,'text',0,'高兴',1,'2024-11-25 10:08:44'),(5,1,'text',0,'高兴',1,'2024-11-25 10:10:39'),(6,2,'text',0,'高兴',1,'2024-11-25 10:19:15'),(7,2,'text',0,'高兴',1,'2024-11-25 10:21:27'),(8,1,'text',0,'高兴',1,'2024-11-25 10:34:56'),(9,2,'text',0,'高兴',1,'2024-11-25 10:38:50'),(10,2,'text',0,'高兴',1,'2024-11-25 10:43:36'),(11,2,'text',0,'高兴',1,'2024-11-25 10:54:25'),(12,2,'face',0,'快乐',1,'2024-11-25 10:57:20'),(13,1,'text',0,'高兴',1,'2024-12-11 15:16:00'),(14,1,'face',0,'恐惧',1,'2024-12-11 15:20:01');
/*!40000 ALTER TABLE `analysis_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `article_id` int NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `title` varchar(255) NOT NULL COMMENT '文章标题',
  `content` text NOT NULL COMMENT '文章内容',
  `summary` varchar(255) NOT NULL COMMENT '文章简介',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedbacks`
--

DROP TABLE IF EXISTS `feedbacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedbacks` (
  `feedback_id` int NOT NULL AUTO_INCREMENT COMMENT '反馈ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `article_id` int DEFAULT NULL COMMENT '文章ID',
  `feedback` enum('like','dislike') DEFAULT NULL COMMENT '反馈类型',
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  KEY `article_id` (`article_id`),
  CONSTRAINT `feedbacks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `feedbacks_ibfk_2` FOREIGN KEY (`article_id`) REFERENCES `articles` (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedbacks`
--

LOCK TABLES `feedbacks` WRITE;
/*!40000 ALTER TABLE `feedbacks` DISABLE KEYS */;
INSERT INTO feedbacks (user_id, article_id, feedback) VALUES (1, 5, 'like'), (2, 6, 'dislike'), (3, 7, 'like'), (4, 8, 'dislike'), (5, 9, 'like'), (1, 10, 'dislike'), (2, 1, 'like'), (3, 2, 'dislike'), (4, 3, 'like'), (5, 4, 'dislike'), (1, 6, 'like'), (2, 7, 'dislike'), (3, 8, 'like'), (4, 9, 'dislike'), (5, 10, 'like'), (1, 2, 'dislike'), (2, 3, 'like'), (3, 4, 'dislike'), (4, 5, 'like'), (5, 6, 'dislike');
/*!40000 ALTER TABLE `feedbacks` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Table structure for table `records_face`
--

DROP TABLE IF EXISTS `records_face`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `records_face` (
  `face_id` int NOT NULL AUTO_INCREMENT COMMENT '表情记录ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `face_imgstr` varchar(100) NOT NULL COMMENT '表情路径',
  `emotion` varchar(10) DEFAULT NULL COMMENT '情绪',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`face_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `records_face_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `records_face`
--

LOCK TABLES `records_face` WRITE;
/*!40000 ALTER TABLE `records_face` DISABLE KEYS */;
INSERT INTO `records_face` VALUES (1,2,'https://emas.oss-cn-beijing.aliyuncs.com/0da1229e-12b7-4421-b6e7-d0baaffc479a.jpg','快乐','2024-11-25 10:57:20'),(2,1,'https://emas.oss-cn-beijing.aliyuncs.com/9bcf783a-1415-4077-9da9-e2a03d9cb96b.jpg','恐惧','2024-12-11 15:20:01');
/*!40000 ALTER TABLE `records_face` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `records_text`
--

DROP TABLE IF EXISTS `records_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `records_text` (
  `text_id` int NOT NULL AUTO_INCREMENT COMMENT '文本记录ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `text` text NOT NULL COMMENT '文本内容',
  `emotion` varchar(10) DEFAULT NULL COMMENT '情绪',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`text_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `records_text_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `records_text`
--

LOCK TABLES `records_text` WRITE;
/*!40000 ALTER TABLE `records_text` DISABLE KEYS */;
INSERT INTO `records_text` VALUES (1,1,'今天天气真好','高兴','2024-11-25 10:01:20'),(2,1,'今天天气真好','高兴','2024-11-25 10:03:21'),(3,1,'今天天气真好','高兴','2024-11-25 10:05:02'),(4,1,'今天天气真好','高兴','2024-11-25 10:08:44'),(5,1,'今天天气真好','高兴','2024-11-25 10:10:39'),(6,2,'今天天气真好','高兴','2024-11-25 10:19:15'),(7,2,'今天天气真好','高兴','2024-11-25 10:21:27'),(8,1,'今天天气真好','高兴','2024-11-25 10:34:56'),(9,2,'今天天气真好','高兴','2024-11-25 10:38:50'),(10,2,'今天天气真好','高兴','2024-11-25 10:43:36'),(11,2,'今天天气真好','高兴','2024-11-25 10:54:25'),(12,1,'今天天气很好','高兴','2024-12-11 15:16:00');
/*!40000 ALTER TABLE `records_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `records_voice`
--

DROP TABLE IF EXISTS `records_voice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `records_voice` (
  `voice_id` int NOT NULL AUTO_INCREMENT COMMENT '语音记录ID',
  `user_id` int DEFAULT NULL COMMENT '用户ID',
  `voice_file_path` varchar(255) NOT NULL COMMENT '语音文件路径',
  `emotion` varchar(10) DEFAULT NULL COMMENT '情绪',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`voice_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `records_voice_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `records_voice`
--

LOCK TABLES `records_voice` WRITE;
/*!40000 ALTER TABLE `records_voice` DISABLE KEYS */;
/*!40000 ALTER TABLE `records_voice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(20) NOT NULL COMMENT '用户名',
  `nickname` varchar(10) DEFAULT NULL COMMENT '昵称',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `email` varchar(25) DEFAULT NULL COMMENT '电子邮件',
  `avatar` varchar(100) DEFAULT NULL COMMENT '头像地址',
  `sex` varchar(10) DEFAULT NULL COMMENT '性别',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'laiyufan','laiyufan','e10adc3949ba59abbe56e057f20f883e','1411331445@qq.com','https://emas.oss-cn-beijing.aliyuncs.com/8bc37212-409d-47c5-9e8a-7060c387b3f3.jpg','男','2024-12-11','2024-11-25 09:56:12','2024-12-11 09:27:03'),
                           (2,'caizhexuan',NULL,'e10adc3949ba59abbe56e057f20f883e',NULL,'https://emas.oss-cn-beijing.aliyuncs.com/0a1a5273-0f10-41ed-8ba5-49e82a9d8e02.jpg',NULL,NULL,'2024-11-25 10:11:56','2024-11-25 10:16:36'),
                           (3,'user3','小刚','password789','user3@example.com','avatar3.jpg','男','1994-03-03','2024-12-12 15:59:57','2024-12-12 15:59:57'),
                           (4,'user4','小丽','passwordabc','user4@example.com','avatar4.jpg','女','1996-04-04','2024-12-12 15:59:57','2024-12-12 15:59:57');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-14 20:34:30

package com.xupt.emas;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.File;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
public class AudioControllerTest {

    @Autowired
    private RestTemplate restTemplate;

    @Test
    public void testSendTwoFiles() {
        // 准备要发送的音频文件路径
        File file1 = new File("C://Users/27641/Desktop/情绪助手/TestFile/audio.wav");
        File file2 = new File("C://Users/27641/Desktop/情绪助手/TestFile/audio.wav");

        // 检查文件是否存在
        assert file1.exists() : "File speaker1 does not exist";
        assert file2.exists() : "File speaker2 does not exist";

        // 设置请求头
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        // 创建 Multipart 请求体
        MultipartBodyBuilder builder = new MultipartBodyBuilder();
        builder.part("speaker1", new FileSystemResource(file1));
        builder.part("speaker2", new FileSystemResource(file2));

        MultiValueMap<String, HttpEntity<?>> multipartRequest = builder.build();

        // 发送请求
        String url = "http://nagy9m.natappfree.cc/verify_audioid";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(multipartRequest, headers), String.class);

        // 检查响应
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue(), "Expected HTTP status 200");
        System.out.println("Response Body: " + response.getBody());
    }
}

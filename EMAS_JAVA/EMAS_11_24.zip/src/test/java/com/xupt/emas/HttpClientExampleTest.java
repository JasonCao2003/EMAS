package com.xupt.emas;

import org.apache.commons.lang3.StringEscapeUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

class HttpClientExampleTest {

    private static final String TEST_URL = "http://nagy9m.natappfree.cc/classify_text2emo";
    private HttpClient client;

    @BeforeEach
    void setUp() {
        client = HttpClient.newHttpClient();
    }

    @Test
    void testRequestForText1() {
        String text1 = "{\"text\":\"拜拜 世界\"}";
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(TEST_URL))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(text1))
                .build();
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String decodedResponse = StringEscapeUtils.unescapeJava(response.body());
            System.out.println("Decoded Response for '拜拜 世界': " + decodedResponse);
            Assertions.assertNotNull(decodedResponse, "Response should not be null for '拜拜 世界'");
        } catch (Exception e) {
            Assertions.fail("Request failed for text: 拜拜 世界", e);
        }
    }

    @Test
    void testRequestForText2() {
        String text2 = "{\"text\":\"你好 世界\"}";
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(TEST_URL))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(text2))
                .build();
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println("Response for '你好 世界': " + response.body());
            Assertions.assertNotNull(response.body(), "Response should not be null for '你好 世界'");
        } catch (Exception e) {
            Assertions.fail("Request failed for text: 你好 世界", e);
        }
    }
}

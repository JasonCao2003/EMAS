package com.xupt.emas.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.xupt.emas.mapper.UserMapper;
import com.xupt.emas.pojo.Users;
import com.xupt.emas.service.UserService;
import com.xupt.emas.utils.Md5Util;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


@Service
public class UserServiceImpl implements UserService {
    @Resource
    private UserMapper userMapper;


    @Override
    public Users getUserById(int userId) {
        return userMapper.selectById(userId);
    }

    @Override
    public Users getUserByUsername(String username) {
        return userMapper.selectOne(new QueryWrapper<Users>().eq("username", username));
    }

    @Override
    public Users getUserByEmail(String email) {
        return userMapper.selectOne(new QueryWrapper<Users>().eq("email", email));
    }

    @Override
    public void updateAvatar(String avatarUrl, Integer userid) {
        userMapper.updateAvatar(avatarUrl, userid);
    }

    @Override
    public void updatePwd(String password, Integer userid) {
        userMapper.updatePwd(password, userid);
    }

    @Override
    public void addUser(String username, String password) {
        Users user = new Users();
        user.setUsername(username);
        user.setPassword(Md5Util.getMD5String(password));
        userMapper.insert(user);
    }

    @Override
    public void updateUser(Users user) {
        userMapper.updateUser(user);
    }

    // 需同时删除外键对应的数据
    @Override
    public void deleteUser(int userId) {
        userMapper.deleteById(userId);
    }
}

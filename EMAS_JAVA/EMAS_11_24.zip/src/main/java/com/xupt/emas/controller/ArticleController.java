package com.xupt.emas.controller;


import com.xupt.emas.pojo.Articles;
import com.xupt.emas.pojo.Feedbacks;
import com.xupt.emas.pojo.Result;
import com.xupt.emas.service.ArticleService;
import com.xupt.emas.utils.ThreadLocalUtil;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@Controller
@Validated
@RequestMapping("/article")
public class ArticleController {

    @Resource
    private ArticleService articleService;

    // 随机返回文章
    @PostMapping("/getRandomArticles")
    public Result<?> getRandomArticles() {
        List<Articles> articles = articleService.getRandomArticles();
        return Result.success(articles);
    }

    // 返回收藏文章
    @PostMapping("/getLikedArticles")
    public Result<?> getLikedArticles() {
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userId = (Integer) map.get("userid");
        List<Articles> articles = articleService.ListLikedArticles(userId);
        return Result.success(articles);
    }

    // 提交文章反馈
    @PostMapping("/submitFeedback")
    public Result<?> submitFeedback(@Valid @RequestBody Feedbacks fd) {
        try {
            Map<String, Object> map = ThreadLocalUtil.get();
            Integer userId = (Integer) map.get("userid");
            Feedbacks feedbacks = new Feedbacks(0, userId, fd.getArticleId(), fd.getFeedback());
            articleService.submitFeedback(feedbacks);
            return Result.success("提交成功");
        } catch (Exception e) {
            return Result.error("提交失败");
        }
    }

    // 获取文章推荐
    /*
    @PostMapping("listRecommends")
    public Result<?> listRecommend() {
        try {
            Map<String, Object> map = ThreadLocalUtil.get();
            Integer userid = (Integer) map.get("userid");
            List<Recommendations> recommends = articleService.recommendArticles(userid);
            return Result.success(recommends);
        } catch (Exception e) {
            return Result.error("获取失败");
        }
    }
    * */
}

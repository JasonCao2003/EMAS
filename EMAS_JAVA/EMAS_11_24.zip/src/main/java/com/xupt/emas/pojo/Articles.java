package com.xupt.emas.pojo;

import lombok.Data;

import java.util.Date;

@Data
public class Articles {
    private Integer articleId; // 文章ID
    private String title; // 文章标题
    private String content; // 文章内容
    private String summary; // 文章简介
    private Date createdAt; // 创建时间
    private Date updatedAt; // 更新时间
}

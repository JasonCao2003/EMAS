package com.xupt.emas.controller;

import com.xupt.emas.pojo.Result;
import com.xupt.emas.pojo.Users;
import com.xupt.emas.service.SparkService;
import com.xupt.emas.service.UserService;
import com.xupt.emas.utils.AliOssUtil;
import com.xupt.emas.utils.MailUtil;
import com.xupt.emas.utils.Md5Util;
import com.xupt.emas.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.Map;
import java.util.UUID;


@RestController
@Validated
@RequestMapping("/user")
public class UserController {

    @Resource
    private UserService userService;
    @Resource
    private SparkService sparkService;
    @Resource
    private MailUtil mailUtil;
    @Autowired
    private StringRedisTemplate redisTemplate;

    // 用户注册
    @RequestMapping("/register")
    public Result<?> register(@Valid @RequestBody Users u) {
        Users user = userService.getUserByUsername(u.getUsername());
        if (user == null) {
            userService.addUser(u.getUsername(), u.getPassword());
            return Result.success();
        }
        return Result.error("用户名已存在");
    }


    // 更新用户信息
    @RequestMapping("/update")
    public Result<?> updateUser(@RequestBody @Validated Users u) {
        try {
            userService.updateUser(u);
            return Result.success("修改成功");
        } catch (Exception e) {
            return Result.error("修改失败");
        }
    }

    // 更新用户头像
    @PostMapping("/updateAvatar")
    public Result<?> updateAvatar(@RequestParam("image") MultipartFile file) {
        try {
            Users user = GetUserInfo();
            String filename = UUID.randomUUID() + ".jpg";
            String filePath = AliOssUtil.UploadFile(filename, file.getInputStream());
            userService.updateAvatar(filePath, user.getUserId());
            return Result.success();
        } catch (Exception e) {
            return Result.error("头像修改失败");
        }
    }

    // 更新用户密码
    @PostMapping("/updatePwd")
    // @RequestHeader("Authorization") String token
    public Result<?> updatePwd(@RequestBody Map<String, String> params) {
        String newPwd = params.get("newPwd");
        String code = params.get("code");
        String oldPwd = params.get("oldPwd");
        String rePwd = params.get("rePwd");

        Users user = GetUserInfo();
        ValueOperations<String, String> operator = redisTemplate.opsForValue();
        if (newPwd.equals(rePwd)) {
            if (Md5Util.getMD5String(oldPwd).equals(user.getPassword())) {
                return Result.error("与原密码相同");
            } else {
                if (code.equals(operator.get(user.getEmail()))) {
                    userService.updatePwd(newPwd, user.getUserId());
                    // 从redis中删除token
//                    operator.getOperations().delete(token);
                    return Result.success("修改成功，请重新登录");
                } else {
                    return Result.error("验证码错误");
                }
            }
        }
        return Result.error("两次密码不同");
    }

    // 发送验证码 （修改密码用）
    @PostMapping("emailValidation")
    public Result<?> emailValidation() {
        Users user = GetUserInfo();
        if (user.getEmail() != null) {
            return mailUtil.SendValidation(user.getEmail());
        }
        return Result.error("此账号未绑定邮箱");
    }

    @PostMapping("/addFaceInfo")
    public Result<?> addFaceInfo(@RequestParam("image") MultipartFile file) throws Exception {
        Users user = GetUserInfo();
        return sparkService.UploadFaceInfo(file, user.getUsername());
    }

    @PostMapping("/addVoiceInfo")
    public Result<?> addVoiceInfo(@RequestParam("audio") MultipartFile file) throws Exception {
        Users user = GetUserInfo();
        return sparkService.UploadVoiceInfo(file, user.getUsername());
    }


    private Users GetUserInfo() {
        // 从ThreadLocal中获取此次请求线程中的userid，并根据id获取用户信息
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer userid = (Integer) map.get("userid");
        return userService.getUserById(userid);
    }

    // 注销
    /* *
    @PostMapping("/deleteUser")
    public Result<?> deleteUser(@Valid @RequestBody Emails em) {
        try {
            Map<String, Object> map = ThreadLocalUtil.get();
            Integer userid = (Integer) map.get("userid");
            Users user = userService.getUserById(userid);
            ValueOperations<String, String> operator = redisTemplate.opsForValue();
            if ((em.getCode()).equals(operator.get(user.getEmail()))) {
                userService.deleteUser(userid);
                return Result.success("已成功注销");
            } else {
                return Result.error("验证码错误");
            }
        } catch (Exception e) {
            return Result.error("注销失败");
        }
    }
    */
}
